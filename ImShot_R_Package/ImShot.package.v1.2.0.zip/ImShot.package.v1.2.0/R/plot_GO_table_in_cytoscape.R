#' @title  plot the GO enrichment  result into the cytoscape window
#' directly using RCy3 package Note: cytoscape window must be already open
#'
#' @param data this is the result returned by clusterProfiler::enrichGO(...) or
#' it is from ImShot GUI (GO table)
#' @param cyto_title title of the netwok in cytoscape
#' @param max_go_show maximum number of GO terms to be displayed
#' @param font_family family of font e.g. Arial, Cambria etc. type ImShot::supported_fonts
#' in RStudio console to see all the supported font families
#' @param gene_font_size font size of genes in the network
#' @param GO_term_font_size font size of GO terms in the network
###################################################################################################
plot_GO_table_in_cytoscape <- function(data,
                                       cyto_title = 'Gene_List',
                                       max_go_show,
                                       font_family,
                                       gene_font_size,
                                       GO_term_font_size) {
    if (nrow(data) > max_go_show) {
        data <- data[1:max_go_show, ]
    }
    
    cyto <- c()
    for (i in 1:nrow(data)) {
        temp <- unlist(strsplit(data$geneID[i], '/'))
        for (j in 1:length(temp)) {
            cyto <-
                rbind(cyto, cbind(temp[j], data$Description[i], length(temp)))
        }
    }
    
    colnames(cyto) <- c('Source', 'Target', 'Count')
    cyto <- as.data.frame(cyto)
    
    ## node attr. table
    temp_source <-
        cbind(
            as.data.frame(unique(cyto$Source)),
            # rep(6, length(unique(cyto$Source))),
            rep(10, length(unique(cyto$Source))),
            rep('#787878', length(unique(cyto$Source))),
            # rep(14, length(unique(cyto$Source))))
            rep(gene_font_size, length(unique(cyto$Source)))
        )
    
    colnames(temp_source) <-
        c('node_name', 'size', 'node_col', 'node_font_size')
    
    temp_target <-
        cbind(
            as.data.frame(data$Description),
            data$Count,
            rep('#E5C494', nrow(data)),
            # rep(18, nrow(data))
            rep(GO_term_font_size, nrow(data))
        )
    colnames(temp_target) <-
        c('node_name', 'size', 'node_col', 'node_font_size')
    
    ## Adjust node sizes to fit to an interval
    # desire_lower_bound <- 10
    # desire_upper_bound <- 16
    desire_lower_bound <- 16
    desire_upper_bound <- 26
    temp_target$size <-
        MapNodeSize(temp_target$size, desire_lower_bound, desire_upper_bound)
    
    ## node table
    temp <- rbind(temp_source, temp_target)
    nodes <- data.frame(id = temp$node_name,
                        stringsAsFactors = FALSE)
    
    node_attr <- data.frame(
        id = nodes$id,
        size = temp$size,
        node_col = temp$node_col,
        node_font_size = temp$node_font_size,
        # node_font_face = rep("Bitstream Vera Sans Bold", nrow(temp)),
        # node_font_face = rep("Arial Bold", nrow(temp)),
        node_font_face = rep(font_family, nrow(temp)),
        stringsAsFactors = FALSE
    )
    # node_attr$node_font_face <- paste(node_attr$node_font_face,
    #                                   'italic',
    #                                   node_attr$node_font_size,
    #                                   sep = ',')

    ## edge table
    edges <- data.frame(
        source = cyto$Source,
        target = cyto$Target,
        interaction = rep(c("interacts"), nrow(cyto)),
        # optional
        # weight = rep(2, nrow(cyto)),
        weight = rep(1, nrow(cyto)),
        # numeric
        stringsAsFactors = FALSE
    )
    
    RCy3::createNetworkFromDataFrames(nodes, edges, title = cyto_title, collection =
                                          "GO Network from DataFrame")
    
    RCy3::loadTableData (data = node_attr,
                         data.key.column = 'id')
    
    ####### Create Visual Styles ###########
    style.name = "Curved"
    defaults <- list(
        # NODE_LABEL_FONT_FACE = paste(font_family, 'Bold', 12, sep = ','),
        # NODE_LABEL_FONT_FACE = font_family,
        # labelFontWeight = 'bold',
        # labelFontWeight = 'italic',
        NODE_SHAPE = "ellipse",
        NODE_BORDER_WIDTH = 1,
        NODE_LABEL_POSITION = "W,E,c,0.00,0.00",
        labelFontWeight = "italic"
    )
    # RCy3::setNodeFontFaceDefault("Dialog,plain,10")
    
    nodeLabels <- RCy3::mapVisualProperty('node label', 'id', 'p')
    
    RCy3::createVisualStyle(style.name,
                            defaults,
                            list(nodeLabels))
    
    RCy3::setVisualStyle(style.name)
    
    RCy3::setNodeColorBypass(node.names = node_attr$id,
                             new.color = node_attr$node_col)
    
    RCy3::setNodeLabelColorDefault(new.color = '#000000',
                                   style.name = style.name)
    
    RCy3::setNodeFontFaceBypass(node.names = node_attr$id,
                                new.fonts = font_family)
    
    RCy3::setNodeSizeBypass(node.names = node_attr$id,
                            new.sizes = as.double(node_attr$size))
    
    RCy3::setNodeFontSizeBypass(node.names = node_attr$id,
                                new.sizes = node_attr$node_font_size)
    # browser()
    # RCy3::setNodeFontFaceBypass(node.names = node_attr$id,
    #                             new.fonts = node_attr$node_font_face)
    
    
    RCy3::setNodeBorderWidthDefault(new.width = 2,
                                    style.name = style.name)
    
    RCy3::setNodeBorderColorDefault(new.color = '#000000',
                                    style.name = style.name)
    
    RCy3::setEdgeTargetArrowShapeDefault(new.shape = "None",
                                         style.name = style.name)
    
    # RCy3::setEdgeColorDefault(new.color = '#999999',
    #                           style.name = style.name) # edge color darker
    
    RCy3::setEdgeColorDefault(new.color = '#666666',
                              style.name = style.name) # edge color darkest
    
    # RCy3::setEdgeColorDefault(new.color = '#d3d3d3',
    #                           style.name = style.name) # edge color lighter
    
    RCy3::setNetworkPropertyBypass(new.value = '#FFFFFF',
                                   visual.property = 'NETWORK_BACKGROUND_PAINT')
    ## Add node sizes as legends
    legend_df <- create_legend_df(data$Count, temp_target$size)
    # browser()
    legend_names <- rownames(legend_df)
    RCy3::addCyNodes(legend_names)
    RCy3::loadTableData(legend_df)
    # Style and position
    # RCy3::setNodeColorBypass(legend_names, "#000000") # legend node black
    RCy3::setNodeColorBypass(legend_names, "#E5C494") # legend node wood color
    if (nrow(legend_df) >= 3) {
        RCy3::setNodePropertyBypass(
            legend_names,
            c("E,W,l,5,0", "E,W,l,5,0", "E,W,l,5,0"),
            "NODE_LABEL_POSITION"
        )
        
        RCy3::setNodePropertyBypass(legend_names,
                                    c("-500", "-500", "-500"),
                                    "NODE_X_LOCATION")
        
        RCy3::setNodePropertyBypass(legend_names,
                                    c("300", "320", "340"),
                                    "NODE_Y_LOCATION")
        
        
    } else if (nrow(legend_df) == 2) {
        RCy3::setNodePropertyBypass(legend_names,
                                    c("E,W,l,5,0", "E,W,l,5,0"),
                                    "NODE_LABEL_POSITION")
        
        RCy3::setNodePropertyBypass(legend_names,
                                    c("-500", "-500"),
                                    "NODE_X_LOCATION")
        
        RCy3::setNodePropertyBypass(legend_names,
                                    c("300", "320"),
                                    "NODE_Y_LOCATION")
        
        RCy3::setNodeLabelBypass(legend_names, legend_df$legend.label)
        RCy3::setNodeSizeBypass(node.names = legend_names,
                                new.sizes = legend_df$size)
    } else {
        RCy3::setNodePropertyBypass(legend_names,
                                    c("E,W,l,5,0"),
                                    "NODE_LABEL_POSITION")
        
        RCy3::setNodePropertyBypass(legend_names,
                                    c("-500"),
                                    "NODE_X_LOCATION")
        
        RCy3::setNodePropertyBypass(legend_names,
                                    c("300"),
                                    "NODE_Y_LOCATION")
        
        RCy3::setNodeLabelBypass(legend_names, legend_df$legend.label)
        RCy3::setNodeSizeBypass(node.names = legend_names,
                                new.sizes = legend_df$size)
    }
    RCy3::setNodeLabelBypass(legend_names, legend_df$legend.label)
    RCy3::setNodeSizeBypass(node.names = legend_names,
                            new.sizes = legend_df$size)
}

################################################################################
#' Map node size to the closed interval [desired_lower_bound, desired_upper_bound]
#' @param node_size size of nodes in the pathway network before mapping
#' @param desired_lower_bound desired lowest value after mapping
#' @param desired_upper_bound desired highest value after mapping
#' @return mapped_node_size node sizes after mapping to the desired interval
#'
MapNodeSize <- function(node_size,
                        desired_lower_bound,
                        desired_upper_bound) {
    current_lower_bound <- min(node_size)
    current_upper_bound <- max(node_size)
    
    if (desired_lower_bound >= desired_upper_bound) {
        stop("CHECK: desired_lower_bound >= desired_upper_bound")
    } else if (current_lower_bound < current_upper_bound) {
        mapped_node_size <-
            (node_size - current_lower_bound) / (current_upper_bound - current_lower_bound) * (desired_upper_bound - desired_lower_bound) + desired_lower_bound
    } else{
        mapped_node_size <- rep(desired_upper_bound, length(node_size))
    }
    return(mapped_node_size)
}

################################################################################
#' Create legend data frame
#' @param actual_node_size size of nodes before mapping
#' @param mapped_node_size size of nodes after mapping
#' @return legend_df legend data frame with node sizes before and after mapping
#'
create_legend_df <- function(actual_node_size,
                             mapped_node_size) {
    if (length(unique(actual_node_size)) >= 3) {
        df <- as.data.frame(cbind(actual_node_size, mapped_node_size))
        x <- sort(df$actual_node_size, index.return = TRUE)
        df <- df[x$ix,]
        idx <-
            match(unique(df$actual_node_size), df$actual_node_size)
        uniq_node_size <- unique(df$actual_node_size)
        idx <- match(uniq_node_size, df$actual_node_size)
        legend_df <- df[idx,]
        print(legend_df)
        colnames(legend_df) <- c("legend.label", "size")
        if (nrow(legend_df) %% 2 == 0) {
            idx <- c(1, 2, nrow(legend_df))
            legend_df <- legend_df[idx,]
        } else{
            idx <- c(1, (1 + nrow(legend_df)) / 2,  nrow(legend_df))
            legend_df <- legend_df[idx,]
        }
        x <- tryCatch({
            rownames(legend_df) <-
                c("legend.size.min",
                  "legend.size.med",
                  "legend.size.max")
        },
        error = function(e) {
            browser()
        })
        
    } else if (length(unique(actual_node_size)) == 2) {
        df <- as.data.frame(cbind(actual_node_size, mapped_node_size))
        colnames(df) <- c("actual_node_size", "mapped_node_size")
        idx_min <-
            which(df$actual_node_size ==  min(df$actual_node_size))
        idx_max <-
            which(df$actual_node_size ==  max(df$actual_node_size))
        legend_df <-
            as.data.frame(df[c(idx_min[1], idx_max[1]),])
        colnames(legend_df) <- c("legend.label", "size")
        rownames(legend_df) <-
            c("legend.size.min", "legend.size.max")
        print(legend_df)
        # return(legend_df)
    } else{
        df <- as.data.frame(cbind(actual_node_size, mapped_node_size))
        colnames(df) <- c("actual_node_size", "mapped_node_size")
        legend_df <-
            as.data.frame(df[1,])
        colnames(legend_df) <- c("legend.label", "size")
        rownames(legend_df) <- c("legend.size.min")
        print(legend_df)
        # return(legend_df)
    }
    return(legend_df)
}