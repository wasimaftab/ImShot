#' This is a pipeline to analyze proteomic data in a
#' proteingroups.txt/peptides.txt (MaxQuant output) file for two group comparision
#'
#' Uses empirical bayes methods from limma R package to compute moderated
#' pvalue.
#' Uses Plotly functions to create and save interactive plots
#'
#' @param mq_file_path Path to the proteingroups.txt/peptides.txt file
#' (MaxQuant output)
#' 
#' @param peptide_or_protein input 0 if the LIMMA is being done using
#' peptides.txt, 1 if the LIMMA is being done using proteingroups.txt
#' 
#' @param lfq_or_ibaq input 1 for LFQ, 2 for iBAQ only when LIMMA is being done
#' using proteingroups.txt (peptide_or_protein = 1). This parameter will be ignored 
#' when peptide_or_protein = 0,
#' 
#' @param norm_method input 1 to "Normalize by subtracting median" and 2 for 
#' "Column wise median normalization" of the data matrix. 
#' 
#' \strong{(i) Normalize by subtracting median:} This method normalizes the protein 
#' intensities in each experiemnt by substrating the median of the corresponding experiment.
#' 
#' \strong{(ii) Column wise median normalization:} This method calculates
#' for each sample the median change (i.e. the difference between the observed 
#' value and the row average) and subtracts it from each row. Missing values are 
#' ignored in the procedure. The method is based on the assumption that a majority 
#' of the rows did not change.
#' If you do not want to normalize just enter any number or skip the parameter altogether.
#' 
#' @param fdr input the desired fdr level to assess whether a differentially expressed 
#' protein/peptide is statistically significant. \strong{default fdr = 0.05}
#' 
#' @param output_folder_path (optional parameter) Path to write the results. By
#' default it creates a timestamped folder inside a subfolder in the user config
#' directory, which is for,
#'
#' Windows = "C:/Users/<User>/AppData/Roaming/ImShot_Electron_App/Results_Limma"
#'
#' Linux = "/home/<User>/.config/ImShot_Electron_App/Results_Limma"
#'
#' Mac = "/Users/<User>/Library/Application Support/ImShot_Electron_App/Results_Limma"
#' @export

two_grp_limma <-
  function(mq_file_path,
           peptide_or_protein,
           lfq_or_ibaq,
           norm_method,
           fdr,
           output_folder_path) {
    writeLines('Doing sanity checks')
    results_folder_name <- 'ImShot_Electron_App'
    if (missing(output_folder_path)) {
      dir.create(file.path(normalizePath(rappdirs::user_config_dir(), winslash = '/'),
                           results_folder_name),
                 showWarnings = FALSE)
      output_folder_path <- normalizePath(file.path(normalizePath(rappdirs::user_config_dir(), winslash = '/'),
                                                    results_folder_name), winslash = '/')
    } else{
      output_folder_path <- normalizePath(output_folder_path, winslash = '/')
    }

    ## Sanity check: stop if mq_file_path variable is missing
    missing_mq_file_path(mq_file_path)

    ## Sanity check: stop if peptide_or_protein variable is missing
    missing_peptide_or_protein(peptide_or_protein)

    ## Sanity check: stop if peptide_or_protein variable holds anything other
    ## than 0 or 1
    value_peptide_or_protein(peptide_or_protein)

    ## Load MaxQuant output proteingrups.txt/peptides.txt
    mq_data <-
      as.data.frame(read.table(mq_file_path,
                               header = TRUE,
                               sep = "\t",
                               check.names = FALSE))
    ## Sanity check: stop if Protein names and Gene names columns are not present
    prot_gene <- c('Protein names', 'Gene names')
    protein_gene_colums_missing(prot_gene, mq_data)

    if (peptide_or_protein) {
      ## LIMMA on proteigroups
      ## Sanity check: stop if lfq_or_ibaq variable is missing when
      ## peptide_or_protein == 1
      lfq_or_ibaq_missing(lfq_or_ibaq)

      ## Sanity check: stop if lfq_or_ibaq variable holds anything
      ## other than 1 or 2
      value_lfq_or_ibaq(lfq_or_ibaq)

      #Sanity check: stop if lfq or ibaq value are absent
      lfq_ibaq_cols_missing(mq_data)

      ## Check if mq_data contain columns with contaminant proteins
      temp <- mq_data_has_conmainats(mq_data)

      if (!ncol(temp)) {
        ## Display data to faciliate choice of treatment and control
        writeLines('Collecting required params from user')
        writeLines('Printing LFQ/iBAQ/Intensity columns names below')
        display_lfq_ibaq_intensity_cols(mq_data,
                                        lfq_or_ibaq,
                                        peptide_or_protein)
        protein_limma(mq_data,
                      norm_method,
                      fdr,
                      lfq_or_ibaq,
                      'Results_Limma',
                      output_folder_path)
      } else {
        ## remove "+" identifeid (in "Only identified by site", "Reverse" or
        ## "Potential contaminant" columns) rows from mq_data
        writeLines('Removing contaminant proteins/peptides')
        mq_data <- remove_contaminants(temp, mq_data, "protein")

        ## Display data to faciliate choice of treatment and control
        writeLines('Collecting required params from user')
        writeLines('Printing LFQ/iBAQ/Intensity columns names below')
        display_lfq_ibaq_intensity_cols(mq_data,
                                        lfq_or_ibaq,
                                        peptide_or_protein)
        protein_limma(mq_data,
                      norm_method,
                      fdr,
                      lfq_or_ibaq,
                      'Results_Limma',
                      output_folder_path)
      }

    } else {# LIMMA on peptides
      ## sanity check if intensity column is missing (in peptides.txt file)
      intensity_cols_missing(mq_data)

      ## Check if mq_data contain columns with contaminant proteins
      temp <- mq_data_has_conmainats(mq_data)

      if (!ncol(temp)) {
        ## Display data to faciliate choice of treatment and control
        writeLines('Collecting required params from user')
        writeLines('Printing LFQ/iBAQ/Intensity columns names below')
        display_lfq_ibaq_intensity_cols(mq_data,
                                        lfq_or_ibaq,
                                        peptide_or_protein)
        peptide_limma(mq_data,
                      norm_method,
                      fdr,
                      'Results_Limma',
                      output_folder_path)
      } else {
        ## remove "+" identifeid (in "Only identified by site", "Reverse" or
        ## "Potential contaminant" columns) rows from mq_data
        writeLines('Removing peptides from contaminant proteins')
        mq_data <- remove_contaminants(temp, mq_data, "peptide")

        ## Display data to faciliate choice of treatment and control
        writeLines('Collecting required params from user')
        writeLines('Printing LFQ/iBAQ/Intensity columns names below')
        display_lfq_ibaq_intensity_cols(mq_data,
                                        lfq_or_ibaq,
                                        peptide_or_protein)
        peptide_limma(mq_data,
                      norm_method,
                      fdr,
                      'Results_Limma',
                      output_folder_path)
      }
    }
  } # END OF two_grp_limma
