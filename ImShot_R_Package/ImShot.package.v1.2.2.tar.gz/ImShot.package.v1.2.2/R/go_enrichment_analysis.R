#' GO enrichment analysis of the protein list(s)
#'
#' @description
#' Performs over-representation test (as implemented in clusterProfiler).
#' This test assesses whether any gene ontology-biological process (GO-BP)
#' annotates the list of proteins at a frequency greater than that would be
#' expected by chance. This substantiates the location of protein(s) in situ by
#' correlating BP to tissue morphology/cell types
#'
#' @param enrichment_path Path to the folder containing gene/protein list(s)
#' @param background_set Path to the text file containing uniprot ids (which we
#' want to use as background for hypergeometric test). This file must be present inside
#' a subfolder (Background) inside enrichment_path folder. If this parameter is missing,
#' then all genes listed in the database (e.g., TERM2GENE table) will be used as background.
#' @param db Genome wide annotation database for differet species,
#' e.g. "org.Mm.eg.db" for mouse
#' @param  ont_domain GO domain name: either "BP", "MF" or "CC"
#' @param min_gs_size Minimal number of genes annotated by Ontology term for testing
#' @param max_gs_size Maximal number of genes annotated for testing
#' @param pvalue_cutoff Adjusted pvalue cutoff on enrichment tests to report
#' @param padjust_method One of "holm", "hochberg", "hommel", "bonferroni", "BH", "BY", "fdr", "none"
#' @param remove_redundant_GO Enter 1 to remove redundancy
#' @param max_GO_show Maximum number of GO-BP terms to be displayed
#' @param output_folder_path (optional parameter) Path to write the results. By
#' default it a timestamped folder inside a subfolder in the user config directory
#' which is for,
#'
#' Windows = "C:/Users/<User>/AppData/Roaming/ImShot_Electron_App/Results_GO"
#'
#' Linux = "/home/<User>/.config/ImShot_Electron_App/Results_GO"
#'
#' Mac = "/Users/<User>/Library/Application Support/ImShot_Electron_App/Results_GO"
#'@export

go_enrichment_analysis <- function(enrichment_path,
                                   background_set = 'Default',
                                   db,
                                   ont_domain,
                                   min_gs_size,
                                   max_gs_size,
                                   pvalue_cutoff,
                                   padjust_method,
                                   remove_redundant_GO,
                                   max_GO_show,
                                   output_folder_path) {
  ## Fix the path
  enrichment_path <-
    normalizePath(enrichment_path, winslash = '/')

  ## check for valid GO domain name
  GO_domains <- c("BP", "MF", "CC")
  if (!ont_domain %in% GO_domains) {
    stop("Check ont_domain name, code will exit now")
  }

  ## Set output folder path if missing
  results_folder_name <- 'ImShot_Electron_App'
  if (missing(output_folder_path)) {
    dir.create(file.path(
      normalizePath(rappdirs::user_config_dir(), winslash = '/'),
      results_folder_name
    ),
    showWarnings = FALSE)
    output_folder_path <-
      normalizePath(file.path(
        normalizePath(rappdirs::user_config_dir(), winslash = '/'),
        results_folder_name
      ),
      winslash = '/')
  } else {
    output_folder_path <-
      normalizePath(output_folder_path, winslash = '/')
  }

  filtered_list <-
    list.files(normalizePath(enrichment_path), '*.xlsx')
  if (length(filtered_list) == 0) {
    stop(paste(
      'There are no filtered masslist in the folder:',
      normalizePath(enrichment_path)
    ))
  }

  ## background selection
  if (background_set != 'Default') {
    background_set <- normalizePath(background_set, winslash = '/')

    ## Background File Sanity Check
    if (!grepl('\\.txt', background_set)) {
      stop(
        'check background_set parameter, background_set should contain fullpath to a text file'
      )
    } else if (!file.exists(background_set)) {
      stop('check background_set parameter, seems the file does not exist')
    }
    bg_uniprot <-
      as.data.frame(read.table(background_set, header = T))
    colnames(bg_uniprot) <- "uniprot"
    # if (colnames(bg_uniprot) != "uniprot") {
    #     stop("check background set column name (case sensitive), code will exit now")
    # }

    ## Convert background Uniprots to ENTREZ IDs
    eg_bg <-
      clusterProfiler::bitr(
        bg_uniprot$uniprot ,
        fromType = "UNIPROT",
        toType = "ENTREZID",
        OrgDb = db
      )
    universe_flag <- 1
  } else {
    universe_flag <- 0
  }

  print(paste("universe_flag = ", universe_flag))

  for (i in 1:length(filtered_list)) {
    file_name <- filtered_list[i]
    full_file_name <-
      paste0(normalizePath(enrichment_path),
             "/",
             file_name)
    T <- as.data.frame(readxl::read_xlsx(full_file_name, 1))
    T <-
      dplyr::select(T, dplyr::matches("uniprot", ignore.case = TRUE))
    colnames(T) <- "uniprot"

    ## convert uniprot to entrez
    eg <-
      clusterProfiler::bitr(T$uniprot,
                            fromType = "UNIPROT",
                            toType = "ENTREZID",
                            OrgDb = db)

    if (db == "org.Sc.sgd.db") {
      ## call GO enrichment function
      if (background_set == 'Default') {
        ego <-
          clusterProfiler::enrichGO(
            gene = eg$ENTREZID,
            OrgDb = db,
            ont = ont_domain,
            pvalueCutoff = pvalue_cutoff,
            pAdjustMethod = padjust_method,
            readable = FALSE,
            minGSSize = min_gs_size,
            maxGSSize = max_gs_size
          )

        ## convert entrez to genename
        if (nrow(ego@result) != 0) {
          entID_res <-
            unique(unlist(strsplit(ego@result$geneID, '/')))
          ego <- replace_enterz_by_symbol(entID_res, ego)
        }
      } else{
        ## construct full path from relative path to read data file for GO analysis
        browser()
        background_set <-
          paste0(enrichment_path,
                 '/Background/',
                 background_set)

        ## read background set
        bg_uniprot <-
          as.data.frame(read.table(background_set, header = TRUE))
        bg_uniprot <-
          dplyr::select(bg_uniprot, dplyr::matches("uniprot"))
        colnames(bg_uniprot) <- "uniprot"

        ## Convert background Uniprots to ENTREZ IDs
        eg_bg <-
          clusterProfiler::bitr(
            bg_uniprot$uniprot ,
            fromType = "UNIPROT",
            toType = "ENTREZID",
            OrgDb = db
          )
        ego <-
          clusterProfiler::enrichGO(
            gene = eg$ENTREZID,
            OrgDb = db,
            universe = eg_bg$ENTREZID,
            ont = ont_domain,
            pvalueCutoff = pvalue_cutoff,
            pAdjustMethod = padjust_method,
            readable = FALSE,
            minGSSize = min_gs_size,
            maxGSSize = max_gs_size
          )

        ## convert entrez to genename
        if (nrow(ego@result) != 0) {
          entID_res <-
            unique(unlist(strsplit(ego@result$geneID, '/')))
          ego <- replace_enterz_by_symbol(entID_res, ego)
        }
      }
    } else{
      ## call GO enrichment function
      if (background_set == 'Default') {
        ego <-
          clusterProfiler::enrichGO(
            gene = eg$ENTREZID,
            OrgDb = db,
            ont = ont_domain,
            pvalueCutoff = pvalue_cutoff,
            pAdjustMethod = padjust_method,
            readable = TRUE,
            minGSSize = min_gs_size,
            maxGSSize = max_gs_size
          )
      } else{
        ## read background set
        bg_uniprot <-
          as.data.frame(read.table(background_set, header = TRUE))
        bg_uniprot <-
          dplyr::select(bg_uniprot, dplyr::matches("uniprot"))
        colnames(bg_uniprot) <- "uniprot"

        ## Convert background Uniprots to ENTREZ IDs
        eg_bg <-
          clusterProfiler::bitr(
            bg_uniprot$uniprot ,
            fromType = "UNIPROT",
            toType = "ENTREZID",
            OrgDb = db
          )
        ego <-
          clusterProfiler::enrichGO(
            gene = eg$ENTREZID,
            OrgDb = db,
            universe = eg_bg$ENTREZID,
            ont = ont_domain,
            pvalueCutoff = pvalue_cutoff,
            pAdjustMethod = padjust_method,
            readable = TRUE,
            minGSSize = min_gs_size,
            maxGSSize = max_gs_size
          )
      }
    }

    ## remove redundant GO terms
    # if (remove_redundant_GO == 'YES' && length(ego) != 0) {
    if (remove_redundant_GO == 'YES' && nrow(ego) != 0) {
      ego <-
        clusterProfiler::simplify(ego,
                                  cutoff = 0.7,
                                  by = "p.adjust",
                                  select_fun = min)
    }

    ## Check if GO df is not empty
    if (nrow(ego@result) != 0) {
      ## Check if GO df contains statistically significant entries
      idx <- which(ego@result$p.adjust < pvalue_cutoff)
      if (length(idx) != 0) {
        data <- ego@result[idx, ]

        ## Plot the Gene-GO network in Cytoscape
        plot_go_cytoscape(data,
                          paste0(gsub('\\.xlsx', "_", file_name), ont_domain),
                          max_GO_show)

        ## Write data dataframe to a file
        dir.create(file.path(output_folder_path, 'Results_GO'),
                   showWarnings = FALSE)
        sub_dir <-
          paste0("Results_GO/",
                 format(Sys.time(), "%Y%m%d_%H%M%S"))
        dir.create(file.path(output_folder_path,
                             sub_dir),
                   showWarnings = FALSE)
        filename_GO_data <-
          paste0(file.path(output_folder_path, sub_dir, fsep = '/'),
                 '/ORT_',
                 file_name)
        writexl::write_xlsx(data, filename_GO_data, col_names = TRUE)

      } else{
        GO_data <- 'No significant GO terms found after p-value adjustment'
      }

    } else{
      GO_data <-
        'EITHER No gene set have size > minGSSize OR No gene set have size < maxGSSize'
    }

    print(paste(filtered_list[i], "processed successfully!"))
  }
}
