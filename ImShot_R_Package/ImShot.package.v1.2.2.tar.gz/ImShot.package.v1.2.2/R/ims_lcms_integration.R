#' Integrates IMS and LCMS datasets at peptide level
#' @description Integrates IMS and LCMS datasets at peptide level by mass matching
#' and MLP scoring
#' @param search_mode Enter 1 to search IMS masslist(s) inside treatment LCMS dataset(s)
#' and 0 to search inside the corresponding control group
#' @param pep_limma_results Path to folder containing results after running two
#' group limma (using peptides.txt)
#' @param deisotoped_ims_dir directory containing deisotoped IMS mass lists
#' @param tol Tolerance for searching IMS masslist in LC-MS masslist
#' @param tol_mlp Search tolerance for resolving ambiguity
#' @param out_path (optional parameter) Path to write the results after IMS-LCMS
#' integration, which by default is,
#'
#' Windows = "C:/Users/<User>/AppData/Roaming/ImShot_Electron_App/Results_MLP/MLP_Filtered_Mass_Lists"
#'
#' Linux = "/home/<User>/.config/ImShot_Electron_App/Results_MLP/MLP_Filtered_Mass_Lists"
#'
#' Mac = "/Users/<User>/Library/Application Support/ImShot_Electron_App/Results_MLP/MLP_Filtered_Mass_Lists"
#' @export

ims_lcms_integration <-
    function(search_mode,
             pep_limma_results,
             deisotoped_ims_dir,
             tol,
             tol_mlp,
             out_path) {
        results_folder_name <- 'ImShot_Electron_App'

        ## Sanity check for IMS masslists and spectrum
        if (missing(search_mode)) {
            stop("MISSING argument: search_mode")
        }
        if (!length(which(c(0, 1) == search_mode))) {
            stop("WRONG search_mode:
        it can only hold 0 (control) and 1 (treatment)")
        }
        if (missing(pep_limma_results)) {
            stop("MISSING argument: pep_limma_results")
        } else{
            pep_limma_results <-
                normalizePath(pep_limma_results, winslash = '/')
        }

        ## Sanity check to find if pep_limma_results folder contain required files
        if (search_mode) {
            l <- '^enriched_treatment'
        } else{
            l <- '^enriched_control'
        }
        p <- list.files(path = pep_limma_results)
        found <-
            grep(paste0(l, collapse = '|'), p, ignore.case = FALSE)

        if (length(found) == 0) {
            status <- 'Failure'
            my_msg <-
                paste(
                    'File not found: No peptide Limma result file for ',
                    search_mode,
                    'found at',
                    pep_limma_results
                )
            return(list(status = status,
                        my_msg = my_msg))
        }

        if (missing(out_path)) {
            dir.create(file.path(
                normalizePath(rappdirs::user_config_dir(), winslash = '/'),
                results_folder_name
            ),
            showWarnings = FALSE)

            out_path <-
                normalizePath(file.path(
                    normalizePath(rappdirs::user_config_dir(), winslash = '/'),
                    results_folder_name
                ),
                winslash = '/')
            dir.create(paste0(
                normalizePath(out_path, winslash = '/'),
                '/',
                'Results_MLP'
            ),
            showWarnings = FALSE)
            out_path <- normalizePath(paste0(
                normalizePath(out_path, winslash = '/'),
                '/',
                'Results_MLP'
            ), winslash = '/')
        } else {
            out_path <- normalizePath(out_path, winslash = '/')

            dir.create(paste0(
                normalizePath(out_path, winslash = '/'),
                '/',
                'Results_MLP'
            ),
            showWarnings = FALSE)

            out_path <- normalizePath(paste0(
                normalizePath(out_path, winslash = '/'),
                '/',
                'Results_MLP'
            ), winslash = '/')
        }

        ## Sanity check to find if deisotoped_ims_dir folder contain required files
        if (missing(deisotoped_ims_dir)) {
            stop("MISSING argument: deisotoped_ims_dir")
        }

        deisotoped_ims_dir <-
            normalizePath(deisotoped_ims_dir, winslash = '/')
        files <-
            list.files(deisotoped_ims_dir, pattern = "\\.xlsx$")

        ## Sanity check for presence of XLSX file in ims_files_full_Path
        if (length(files) == 0) {
            stop(paste("No XLSX file found in", deisotoped_ims_dir))
        }

        # tol <- 0.1
        ## in case of mlp scoring, use increased tolerance
        ## to make sure boundary is achieved
        # tol_mlp <- 0.2

        ## Create folder to save deisotoped mass list(s)
        result_folder <- "MLP_Filtered_Mass_Lists"
        result_folder_full_path <- paste0(out_path,
                                          '/',
                                          result_folder)
        dir.create(result_folder_full_path, showWarnings = FALSE)

        ## Create log file
        log_file = paste0(out_path, '/',
                          result_folder,
                          '/FAILURE_LOG_FILE.txt')

        limma_files <- p[found]

        ###### START: For Loop over files ######
        for (i in 1:length(files)) {
            file_name_with_path <-
                paste0(deisotoped_ims_dir, "/", files[i])
            deisotoped_mass_list <-
                as.data.frame(readxl::read_xlsx(
                    file_name_with_path,
                    sheet = 1,
                    col_names = TRUE
                ))
            deisotoped_mass_list <-
                deisotoped_mass_list$ims_mass_deisotoped

            ################ START: tolerance search module ################
            for (j in 1:length(limma_files)) {
                limma_pep_df <- as.data.frame(readxl::read_xlsx (
                    paste0(pep_limma_results,
                           '/',
                           limma_files[j]),
                    col_names = TRUE
                ))

                limma_pep_df_filtered <-
                    search_within_tolerance(tol,
                                            deisotoped_mass_list,
                                            limma_pep_df)
                log_file_tag <- paste0(
                    'mlp_',
                    stringr::str_extract(
                        limma_files[j],
                        # '(?<=enriched_(treatment|control)_).*(?=\\.tsv)'
                        '(?<=enriched_(treatment|control)_).*(?=\\.xlsx)'
                    ),
                    '_',
                    search_mode,
                    '_LCMS:'
                )
                if (length(limma_pep_df_filtered) == 0) {
                    write_log(files[i],
                              log_file_tag,
                              log_file)
                } else{
                    mlp_filtered_pep_df <- mlp_filtering(limma_pep_df_filtered,
                                                         tol_mlp)
                    write_mlp_filtering(
                        mlp_filtered_pep_df,
                        result_folder_full_path,
                        files[i],
                        log_file_tag
                    )
                }
            }
            ################ END: tolerance search module ################
        }
    }
