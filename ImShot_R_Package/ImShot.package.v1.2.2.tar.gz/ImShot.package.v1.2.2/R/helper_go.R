################################################################################
replace_enterz_by_symbol <- function(entID_res, ego) {
  ent2symbol <-
    clusterProfiler::bitr(entID_res,
                          fromType = "ENTREZID",
                          toType = "GENENAME",
                          OrgDb = db)
  if (length(ent2symbol$GENENAME) != length(entID_res)) {
    ## use entrez ids for those that failed to map to genename in the network plot
    ent_not_mapped <- setdiff(entID_res, ent2symbol$ENTREZID)
    if (length(ent_not_mapped) > 1) {
      temp <- cbind(ent_not_mapped, ent_not_mapped)
      colnames(temp) <- colnames(ent2symbol)
      ent2symbol <- rbind(ent2symbol, temp)
      # browser()
    } else{
      ent2symbol <- rbind(ent2symbol, c(ent_not_mapped, ent_not_mapped))
      # browser()
    }
  }
  
  result <- ego@result
  symbol <- c()
  for (i in 1:nrow(result)) {
    res <- map_enterz_to_symbol(ent2symbol, result$geneID[i])
    symbol <- c(symbol, res)
  }
  result$geneID <- symbol
  ego@result <- result
  return(ego)
}
################################################################################
map_enterz_to_symbol <- function(ent2symbol, entrez) {
  if (grepl('/', entrez)) {
    temp <- unlist(strsplit(entrez, '/'))
    res <-
      subset(ent2symbol, grepl(paste(temp, collapse = "|"), ENTREZID))
    res <- paste0(res$GENENAME, collapse = '/')
  } else{
    res <-
      subset(ent2symbol, grepl(paste(entrez, collapse = "|"), ENTREZID))
    res <- res$GENENAME
  }
  return(res)
}
################################################################################
#' @title  plot the GO enrichment enrichment result into the cytoscape window
#' directly using RCy3 package Note: cytoscape window must be already open
#' @param data this is the result returned by clusterProfiler::enrichGO(...)
#' @param cyto_title title of the netwok in cytoscape
#' @param max_go_show maximum number of GO-BP terms to be displayed

plot_go_cytoscape <- function(data, cyto_title, max_go_show) {
  if (nrow(data) > max_go_show) {
    data <- data[1:max_go_show, ]
  }

  cyto <- c()
  for (i in 1:nrow(data)) {
    temp <- unlist(strsplit(data$geneID[i], '/'))
    for (j in 1:length(temp)) {
      cyto <-
        rbind(cyto, cbind(temp[j], data$Description[i], length(temp)))
    }
  }

  colnames(cyto) <- c('Source', 'Target', 'Count')
  cyto <- as.data.frame(cyto)

  ## node attr. table
  temp_source <-
    cbind(as.data.frame(unique(cyto$Source)),
          rep(6, length(unique(cyto$Source))),
          rep('#787878', length(unique(cyto$Source))),
          rep(14, length(unique(cyto$Source))))
  colnames(temp_source) <-
    c('node_name', 'size', 'node_col', 'node_font_size')

  temp_target <-
    cbind(
      as.data.frame(data$Description),
      data$Count,
      rep('#E5C494', nrow(data)),
      rep(18, nrow(data))
    )
  colnames(temp_target) <-
    c('node_name', 'size', 'node_col', 'node_font_size')

  ## Adjust node sizes to fit to an interval
  desire_lower_bound <- 10
  desire_upper_bound <- 16
  temp_target$size <-
    MapNodeSize(temp_target$size, desire_lower_bound, desire_upper_bound)

  ## node table
  temp <- rbind(temp_source, temp_target)
  nodes <- data.frame(id = temp$node_name,
                      stringsAsFactors = FALSE)

  node_attr <- data.frame(
    id = nodes$id,
    size = temp$size,
    node_col = temp$node_col,
    node_font_size = temp$node_font_size,
    node_font_face = rep("Bitstream Vera Sans Bold", nrow(temp)),
    stringsAsFactors = FALSE
  )

  ## edge table
  edges <- data.frame(
    source = cyto$Source,
    target = cyto$Target,
    interaction = rep(c("interacts"), nrow(cyto)),
    # optional
    weight = rep(2, nrow(cyto)),
    # numeric
    stringsAsFactors = FALSE
  )

  RCy3::createNetworkFromDataFrames(nodes, edges, title = cyto_title, collection =
                                      "GO Network from DataFrame")

  RCy3::loadTableData (data = node_attr,
                       data.key.column = 'id')

  ####### Create Visual Styles ###########
  style.name = "Curved"
  defaults <- list(
    NODE_SHAPE = "ellipse",
    NODE_BORDER_WIDTH = 1,
    NODE_LABEL_POSITION = "W,E,c,0.00,0.00"
  )
  nodeLabels <- RCy3::mapVisualProperty('node label', 'id', 'p')

  RCy3::createVisualStyle(style.name,
                          defaults,
                          list(nodeLabels))

  RCy3::setVisualStyle(style.name)

  RCy3::setNodeColorBypass(node.names = node_attr$id,
                           new.color = node_attr$node_col)

  RCy3::setNodeLabelColorDefault(new.color = '#000000',
                                 style.name = style.name)

  RCy3::setNodeSizeBypass(node.names = node_attr$id,
                          new.sizes = as.double(node_attr$size))

  RCy3::setNodeFontSizeBypass(node.names = node_attr$id,
                              new.sizes = node_attr$node_font_size)

  RCy3::setNodeFontFaceBypass(node.names = node_attr$id,
                              new.fonts = node_attr$node_font_face)

  RCy3::setNodeBorderWidthDefault(new.width = 2,
                                  style.name = style.name)

  RCy3::setNodeBorderColorDefault(new.color = '#000000',
                                  style.name = style.name)

  RCy3::setEdgeTargetArrowShapeDefault(new.shape = "None",
                                       style.name = style.name)

  RCy3::setEdgeColorDefault(new.color = '#999999',
                            style.name = style.name)

  RCy3::setNetworkPropertyBypass(new.value = '#FFFFFF',
                                 visual.property = 'NETWORK_BACKGROUND_PAINT')
  ## Add node sizes as legends
  legend_df <- create_legend_df(data$Count, temp_target$size)
  # browser()
  legend_names <- rownames(legend_df)
  RCy3::addCyNodes(legend_names)
  RCy3::loadTableData(legend_df)
  # Style and position
  RCy3::setNodeColorBypass(legend_names, "#000000")
  if (nrow(legend_df) >= 3) {
    RCy3::setNodePropertyBypass(legend_names,
                          c("E,W,l,5,0", "E,W,l,5,0", "E,W,l,5,0"),
                          "NODE_LABEL_POSITION")

    RCy3::setNodePropertyBypass(legend_names,
                          c("-500", "-500", "-500"),
                          "NODE_X_LOCATION")

    RCy3::setNodePropertyBypass(legend_names,
                          c("300", "320", "340"),
                          "NODE_Y_LOCATION")


  } else if (nrow(legend_df) == 2){
    RCy3::setNodePropertyBypass(legend_names,
                          c("E,W,l,5,0", "E,W,l,5,0"),
                          "NODE_LABEL_POSITION")

    RCy3::setNodePropertyBypass(legend_names,
                          c("-500", "-500"),
                          "NODE_X_LOCATION")

    RCy3::setNodePropertyBypass(legend_names,
                          c("300", "320"),
                          "NODE_Y_LOCATION")

    RCy3::setNodeLabelBypass(legend_names, legend_df$legend.label)
    RCy3::setNodeSizeBypass(node.names = legend_names,
                      new.sizes = legend_df$size)
  } else {
    RCy3::setNodePropertyBypass(legend_names,
                          c("E,W,l,5,0"),
                          "NODE_LABEL_POSITION")

    RCy3::setNodePropertyBypass(legend_names,
                          c("-500"),
                          "NODE_X_LOCATION")

    RCy3::setNodePropertyBypass(legend_names,
                          c("300"),
                          "NODE_Y_LOCATION")

    RCy3::setNodeLabelBypass(legend_names, legend_df$legend.label)
    RCy3::setNodeSizeBypass(node.names = legend_names,
                      new.sizes = legend_df$size)
  }
  RCy3::setNodeLabelBypass(legend_names, legend_df$legend.label)
  RCy3::setNodeSizeBypass(node.names = legend_names,
                    new.sizes = legend_df$size)
}
###################################################################################################