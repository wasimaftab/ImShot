################################################################################
#' select a directory
#' @param my_caption user defined caption
select_folder <- function(my_caption) {
    if (exists('utils::choose.dir')) {
        choose.dir(caption = my_caption)
    } else {
        tcltk::tk_choose.dir(caption = my_caption)
    }
}
################################################################################
#' select a file
#' @param my_caption user defined caption
select_file <- function(my_caption) {
    if (exists('utils::choose.files')) {
        choose.files(caption = my_caption, multi = FALSE)
    } else {
        tcltk::tk_choose.files(caption = my_caption, multi = FALSE)
    }
}
################################################################################
#' Map edge thichness to the closed interval [desired_lower_bound, desired_upper_bound]
#' @param edge_thickness thickness of edges in the pathway network before mapping
#' @param desired_lower_bound desired lowest value after mapping
#' @param desired_upper_bound desired highest value after mapping
#' @return mapped_edge_thickness edge thicknesses after mapping to the desired
#' interval
#'
MapEdgeThickNess <- function(edge_thickness,
                             desired_lower_bound,
                             desired_upper_bound) {
    current_lower_bound <- min(edge_thickness)
    current_upper_bound <- max(edge_thickness)

    if (desired_lower_bound >= desired_upper_bound){
        stop("CHECK: desired_lower_bound >= desired_upper_bound")
    } else if (current_lower_bound < current_upper_bound) {
        mapped_edge_thickness <-
            (edge_thickness - current_lower_bound) / (current_upper_bound - current_lower_bound) * (desired_upper_bound - desired_lower_bound) + desired_lower_bound
    } else{
        mapped_edge_thickness <- rep(current_upper_bound, length(edge_thickness))
    }
    return(mapped_edge_thickness)
}
################################################################################
#' Map node size to the closed interval [desired_lower_bound, desired_upper_bound]
#' @param node_size size of nodes in the pathway network before mapping
#' @param desired_lower_bound desired lowest value after mapping
#' @param desired_upper_bound desired highest value after mapping
#' @return mapped_node_size node sizes after mapping to the desired interval
#'
MapNodeSize <- function(node_size,
                        desired_lower_bound,
                        desired_upper_bound) {
    current_lower_bound <- min(node_size)
    current_upper_bound <- max(node_size)

    if (desired_lower_bound >= desired_upper_bound) {
        stop("CHECK: desired_lower_bound >= desired_upper_bound")
    } else if (current_lower_bound < current_upper_bound) {
        mapped_node_size <-
            (node_size - current_lower_bound) / (current_upper_bound - current_lower_bound) * (desired_upper_bound - desired_lower_bound) + desired_lower_bound
    } else{
        mapped_node_size <- rep(desired_upper_bound, length(node_size))
    }
    return(mapped_node_size)
}
################################################################################
#' Create legend data frame
#' @param actual_node_size size of nodes before mapping
#' @param mapped_node_size size of nodes after mapping
#' @return legend_df legend data frame with node sizes before and after mapping
#'
create_legend_df <- function(actual_node_size,
                           mapped_node_size) {
    if (length(unique(actual_node_size)) >= 3) {
        df <- as.data.frame(cbind(actual_node_size, mapped_node_size))
        x <- sort(df$actual_node_size, index.return=TRUE)
        df <- df[x$ix,]
        idx <- match(unique(df$actual_node_size), df$actual_node_size)
        uniq_node_size <- unique(df$actual_node_size)
        idx <- match(uniq_node_size, df$actual_node_size)
        legend_df <- df[idx,]
        print(legend_df)
        colnames(legend_df) <- c("legend.label", "size")
        if (nrow(legend_df) %% 2 == 0){
            idx <- c(1, 2, nrow(legend_df))
            legend_df <- legend_df[idx,]
        }else{
           idx <- c(1, (1+nrow(legend_df))/2,  nrow(legend_df))
           legend_df <- legend_df[idx,]
        }
        x <- tryCatch(
            {
            rownames(legend_df) <-
                c("legend.size.min", "legend.size.med", "legend.size.max")
            },
            error = function(e){
                browser()
            }
        )

    } else if(length(unique(actual_node_size)) == 2){
        df <- as.data.frame(cbind(actual_node_size, mapped_node_size))
        colnames(df) <- c("actual_node_size", "mapped_node_size")
        idx_min <- which(df$actual_node_size ==  min(df$actual_node_size))
        idx_max <-
            which(df$actual_node_size ==  max(df$actual_node_size))
        legend_df <-
            as.data.frame(df[c(idx_min[1], idx_max[1]),])
        colnames(legend_df) <- c("legend.label", "size")
        rownames(legend_df) <- c("legend.size.min", "legend.size.max")
        print(legend_df)
        # return(legend_df)
    }else{
        df <- as.data.frame(cbind(actual_node_size, mapped_node_size))
        colnames(df) <- c("actual_node_size", "mapped_node_size")
        legend_df <-
            as.data.frame(df[1,])
        colnames(legend_df) <- c("legend.label", "size")
        rownames(legend_df) <- c("legend.size.min")
        print(legend_df)
        # return(legend_df)
    }
    return(legend_df)
}
################################################################################
