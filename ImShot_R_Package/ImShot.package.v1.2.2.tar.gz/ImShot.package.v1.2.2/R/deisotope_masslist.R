#' Generates mono-isotopic IMS mass lists by filtering overlapping spectra
#' @description  Deisotopes IMS mass list(s) based on user defined tolerance.
#' Using entire IMS spectrum fixes non-apical peak assignments (as found in some cases by
#' proprietary software e.g., SCiLS lab). The folder containing ims masslists and
#' the ims spectrum file are selected interactively.
#' 
#' @param IMS_masslists_folder Absolute path to the folder containing IMS masslists (clusters)
#'  corresponding a particular group (disease/healthy)
#'  
#' @param IMS_spectrum_file Absolute path to the IMS spectrum file of the corresponding group
#' 
#' @param tol Tolerance for deisotoping
#'
#' @param output_folder_path (optional) Folder path to write the desiotoped masslists.
#' Default path is Deisotoped_Mass_Lists folder located inside user config directory
#' which is for,
#'
#' Windows = "C:/Users/<User>/AppData/Roaming/ImShot_Electron_App"
#'
#' Linux = "/home/<User>/.config/ImShot_Electron_App"
#'
#' Mac = "/Users/<User>/Library/Application Support/ImShot_Electron_App"
#' @export

deisotope_masslist <-
  function(IMS_masslists_folder,
           IMS_spectrum_file,
           tol,
           output_folder_path) {
    results_folder_name <- 'ImShot_Electron_App'
    IMS_masslists_folder <- normalizePath(IMS_masslists_folder, winslash = '/')
    IMS_spectrum_file <- normalizePath(IMS_spectrum_file, winslash = '/')
    
    ## Sanity check for IMS masslists and spectrum
    if (is.na(IMS_masslists_folder)) {
      stop("MISSING IMS_masslists_folder: Please select folder containing IMS masslists")
    }
    if (length(IMS_spectrum_file) == 0) {
      stop("MISSING IMS_spectrum_file: Please select IMS spectrum file")
    }
    if (missing(output_folder_path)) {
      dir.create(file.path(
        normalizePath(rappdirs::user_config_dir(), winslash = '/'),
        results_folder_name
      ),
      showWarnings = FALSE)
      output_folder_path <-
        normalizePath(file.path(
          normalizePath(rappdirs::user_config_dir(), winslash = '/'),
          results_folder_name
        ),
        winslash = '/')
    } else{
      output_folder_path <-
        normalizePath(output_folder_path, winslash = '/')
    }
    
    ims_files_full_Path <-
      normalizePath(IMS_masslists_folder, winslash = '/')
    files <-
      list.files(ims_files_full_Path, pattern = "\\.xlsx$")
    
    ## Sanity check for presence of XLSX file in ims_files_full_Path
    if (length(files) == 0) {
      stop(paste("No XLSX file found in", ims_files_full_Path))
    }
    result_folder <- "Deisotoped_Mass_Lists"
    ## Create folder to save deisotoped mass list(s)
    create_output_folder(output_folder_path, result_folder)
    
    ## Create log file
    log_file = paste0(output_folder_path,
                      '/',
                      result_folder,
                      '/FAILURE_LOG_FILE.txt')
    # tol <- 0.1
    for (i in 1:length(files)) {
      file_name_with_path <-
        paste0(ims_files_full_Path, "/", files[i])
      ims_mass_list <-
        as.data.frame(readxl::read_xlsx(
          file_name_with_path,
          sheet = 1,
          col_names = TRUE
        ))
      
      ## Sanity check for correct data format in ims mass lists (XLSX files)
      ## Desistoping
      if (typeof(ims_mass_list[, 1]) != 'double') {
        stop('IMS masslist must be of type double')
      }
      ims_mass_deisotoped <- deisotoping(ims_mass_list[, 1], tol)
      
      ## Fix Scills Lab's wrong Peak assignment
      ims_spectrum_file <-
        normalizePath(IMS_spectrum_file, winslash = '/')
      ims_spectrum <-
        readxl::read_xlsx(ims_spectrum_file, col_names = TRUE)
      ims_mass_round <- trunc(ims_mass_deisotoped)
      consecutive_masses <- find_consecutive_masses(ims_mass_round)
      if (length(consecutive_masses) != 0) {
        mass_corrected <- correct_masses(consecutive_masses, ims_spectrum)
        `%in%` <- base::'%in%'
        idx <- which(ims_mass_round %in% consecutive_masses)
        ims_mass_deisotoped[idx] <- mass_corrected
        
        ## Second round of desisotoping
        ims_mass_deisotoped <- deisotoping(ims_mass_deisotoped, tol)
        file_name_deisotoped_list <-
          paste0(
            file.path(output_folder_path, "Deisotoped_Mass_Lists"),
            "/",
            gsub(".xlsx", "_desisotoped.xlsx", files[i])
          )
        
        writexl::write_xlsx(as.data.frame(ims_mass_deisotoped),
                            file_name_deisotoped_list,
                            col_names = TRUE)
      } else {
        file_name_deisotoped_list <-
          paste0(
            file.path(output_folder_path, "Deisotoped_Mass_Lists"),
            "/",
            gsub(".xlsx", "_desisotoped.xlsx", files[i])
          )
        writexl::write_xlsx(as.data.frame(ims_mass_deisotoped),
                            file_name_deisotoped_list,
                            col_names = TRUE)
      }
    } # END OF FOR LOOP
  } # END OF deisotope_masslist
