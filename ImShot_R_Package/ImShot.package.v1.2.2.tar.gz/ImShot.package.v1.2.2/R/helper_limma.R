######################Sanity Checks#############################################
#'remove carbamidomethyl modifications
#' @param mq_data dataframe from MQ peptides.txt after removal of contaminants
remove_carbamidomethyl_modifications <- function(mq_data){
  carbamidomethyl_mod_mass <- 57.02
  idx <- which(mq_data$`C Count` != 0)
  modified_mass <- mq_data$Mass[idx]
  corrected_mass <- modified_mass - carbamidomethyl_mod_mass * mq_data$`C Count`[idx]
  mq_data$Mass[idx] <- corrected_mass
  return(mq_data)
}

## Impute missing values based on the selected algorithm
impute_missing_values <- function(mtx, method) {
  tryCatch({
    if (method == "impSeqRob") {
      mtx_imp <- rrcovNA::impSeqRob(mtx)
      mtx_imp <- mtx_imp$x
    } else if (method == "impSeq") {
      mtx_imp <- rrcovNA::impSeq(mtx)
    } else if (method == "missForest") {
      temp <- missForest::missForest(mtx)
      mtx_imp <- temp$ximp
    } else if (method == "imputePCA") {
      temp <- missMDA::imputePCA(data.frame(mtx), nboot = 1)
      mtx_imp <- temp$completeObs
    } else if (method == "MIPCA") {
      # temp <- missMDA::imputePCA(data.frame(mtx), nboot = 1)
      temp <- missMDA::MIPCA(data.frame(mtx), nboot = 1)
      mtx_imp <- temp$res.imputePCA
    } else if (method == "ppca" || method == "bpca") {
      mtx[is.na(mtx)] <- NA
      if (sum(rowSums(is.na(mtx)) >= ncol(mtx)) > 0) {
        mtx_imp <- {
        }
      } else {
        temp <- pcaMethods::pca(mtx, method = method)
        mtx_imp <- pcaMethods::completeObs(temp)
      }
    } else if (method == "kNNImpute") {
      temp <- imputation::kNNImpute(mtx, k = 3)
      mtx_imp <- temp$x
    } else if (method == "SVDImpute") {
      temp <- imputation::SVDImpute(mtx, k = 3)
      mtx_imp <- temp$x
    } else if (method == "tiny") {
      data_limma <- mtx
      # data_limma[is.infinite(data_limma)] <- NA
      nan_idx <- which(is.na(data_limma))
      fit <- MASS::fitdistr(c(na.exclude(data_limma)), "normal")
      mu <- as.double(fit$estimate[1])
      sigma <- as.double(fit$estimate[2])
      sigma_cutoff <- 6
      new_width_cutoff <- 0.3
      downshift <- 1.8
      width <- sigma_cutoff * sigma
      new_width <- width * new_width_cutoff
      new_sigma <- new_width / sigma_cutoff
      new_mean <- mu - downshift * sigma
      imputed_vals_my = rnorm(length(nan_idx), new_mean, new_sigma)
      data_limma[nan_idx] <- imputed_vals_my
      mtx_imp <- data_limma
    }
  }, error = function(e) {
    mtx_imp <<- NULL
    warning(paste(
      'Error executing R function',
      method,
      ':',
      conditionMessage(e)
    ))
  })
  return(mtx_imp)
}


## Column wise median normalization
median_normalization <- function(X, spike_in_rows = NULL) {
  if (is.matrix(X)) {
    stopifnot(length(dim(X)) == 2)
    if (is.null(spike_in_rows)) {
      # Use all rows for normalization
      spike_in_rows <- seq_len(nrow(X))
    } else if (!is.numeric(spike_in_rows) &&
               !is.logical(spike_in_rows)) {
      stop("spike_in_rows must either be a numeric or a logical vector")
    } else if (is.logical(spike_in_rows)) {
      if (length(spike_in_rows) != nrow(X)) {
        stop("The spike_in_rows logical vector must have one entry for each row.")
      } else if (all(spike_in_rows == FALSE)) {
        stop("Not all elements of the spike_in_rows vector can be FALSE.")
      }
    }
    Xnorm <- X
    for (idx in seq_len(ncol(X))) {
      Xnorm[, idx] <- X[, idx, drop = FALSE] -
        median(X[spike_in_rows, idx, drop = FALSE] - rowMeans(X[spike_in_rows, , drop =
                                                                  FALSE], na.rm = TRUE), na.rm = TRUE)
    }
    return(Xnorm)
  } else{
    stop("The data is not in matrix format, can't normalize!")
  }
}


#' Sanity check: stop if mq_file_path variable is missing
#' @param mq_file_path path to the MaxQuant output file
missing_mq_file_path <- function(mq_file_path) {
  if (missing(mq_file_path)) {
    stop('mq_file_path variable is missing')
  }
}

#' Sanity check: stop if peptide_or_protein variable is missing
#' @param peptide_or_protein binary argument to detemine whether LIMMA t-test done is
#' to done using proteins/peptides
#'
missing_peptide_or_protein <- function(peptide_or_protein) {
  if (missing(peptide_or_protein)) {
    stop('peptide_or_protein variable is missing')
  }
}

#' Sanity check: stop if peptide_or_protein variable holds anything other
#' than 0 or 1
#' @param peptide_or_protein binary argument to detemine whether LIMMA t-test
#' to be done using proteins/peptides
value_peptide_or_protein <- function(peptide_or_protein) {
  if (!length(which(c(0, 1) == peptide_or_protein))) {
    stop(
      paste(
        'peptide_or_protein variable can hold either 1 or 0',
        'input 0 if the LIMMA is being done using peptides.txt,
          1 if the LIMMA is being done using proteingrups.txt',
        sep = '\n'
      )
    )
  }
}

#' Sanity check: stop if lfq_or_ibaq variable is missing when
#' peptide_or_protein == 1
#' @param lfq_or_ibaq select LFQ or iBAQ columns
lfq_or_ibaq_missing <- function(lfq_or_ibaq) {
  if (missing(lfq_or_ibaq)) {
    stop('lfq_or_ibaq variable can\'t be missing
             when peptide_or_protein is 1')
  }
}

#' Sanity check: stop if lfq_or_ibaq variable holds anything
#' other than 1 or 2
#' @param lfq_or_ibaq select LFQ or iBAQ columns
value_lfq_or_ibaq <- function(lfq_or_ibaq) {
  if (!length(which(c(1, 2) == lfq_or_ibaq))) {
    stop(
      paste(
        'lfq_or_ibaq variable can hold either 1 or 2',
        'input 1 for LFQ and 2 for iBAQ',
        sep = '\n'
      )
    )
  }
}

#' Sanity check: stop if Protein names and Gene names columns are not present
#' @param prot_gene list holding required columns names for proteins and genes
#' @param mq_data dataframe hodling data for LIMMA t-test
protein_gene_colums_missing <- function(prot_gene, mq_data) {
  pat <- paste0('(', prot_gene[1], '|', prot_gene[2], ')')
  if (length(grep(
    pattern = pat,
    x = colnames(mq_data),
    ignore.case = TRUE
  )) != length(prot_gene)) {
    stop('Protein names and/or Gene names columns are not present')
  }
}

#' Sanity check: stop if lfq or ibaq value are absent
#' @param mq_data dataframe hodling data for LIMMA t-test
lfq_ibaq_cols_missing <- function(mq_data) {
  temp <- dplyr::select(mq_data, dplyr::matches("(lfq|ibaq)"))
  if (!(ncol(temp) * nrow(temp))) {
    stop('lfq or ibaq columns are absent')
  }
}

#' Check if mq_data contain columns with contaminant proteins
#' @param mq_data dataframe hodling data for LIMMA t-test
mq_data_has_conmainats <- function(mq_data) {
  pat <- "(Only identified by site|Reverse|Potential contaminant)"
  idx <- grep(pat, colnames(mq_data))
  temp <- mq_data[, idx]
  return(temp)
}

#' Display data to faciliate choice of treatment and control
#' @param mq_data dataframe hodling data for LIMMA t-test
#' @param lfq_or_ibaq select LFQ or iBAQ columns
#' @param peptide_or_protein binary argument to detemine whether LIMMA t-test
#' to be done using proteins/peptides
display_lfq_ibaq_intensity_cols <- function(mq_data, lfq_or_ibaq,
                                            peptide_or_protein) {
  if (peptide_or_protein) {
    if (lfq_or_ibaq == 1) {
      temp <- dplyr::select(mq_data, dplyr::matches("lfq"))
    } else {
      temp <- dplyr::select(mq_data, dplyr::matches("ibaq"))
    }
    writeLines(colnames(temp))
  } else{
    temp <- dplyr::select(mq_data, dplyr::matches("intensity"))
    writeLines(colnames(temp))
  }
}

#' remove "+" identifeid (in "Only identified by site", "Reverse" or
#' "Potential contaminant" columns) rows from mq_data
#' @param temp temporary dataframe containing contaminat columns
#' @param mq_data MQ output
#' @param type_molecule protein/peptide
remove_contaminants <- function(temp, mq_data, type_molecule) {
  idx <- NULL
  for (i in 1:ncol(temp)) {
    index <- which(unlist(!is.na(match(temp[, i], "+"))))
    idx <- union(idx, index)
  }
  if (length(idx) != 0) {
    mq_data <- mq_data[-idx, ] # removing indexed rows
    print(paste(
      "Removed",
      length(idx),
      "contaminat",
      paste0(type_molecule, "s")
    ))
  } else{
    print("No contaminat proteins found!!")
  }
  return(mq_data)
}

#' sanity check if intensity column is missing (in peptides.txt file)
#' @param mq_data data from MQ output
intensity_cols_missing <- function(mq_data) {
  temp <- dplyr::select(mq_data, dplyr::matches("intensity"))
  if (!(ncol(temp) * nrow(temp))) {
    stop('intensity columns are absent')
  }
}
################################################################################
remove_exclusives <-
  function(data,
           rep_treats,
           rep_conts,
           control,
           treatment,
           type_molecule) {
    writeLines(
      paste(
        'Removing',
        paste0(type_molecule, 's'),
        'with all zeros in treatment replicates and
      all/some values in control replicates'
      )
    )
    ## Filter out proteins/peptides with all zeros in treatment
    ## (values in control don't care)
    ## see followig example
    ## treat1 treat2 treat3 cont1 cont2 cont3 uniprot gene_names
    ## ---------------------------------------------------------
    ##  0       0       0     0  2810900  0    Q02888   INA17
    temp <-
      as.matrix(rowSums(apply(data[, 1:rep_treats], 2, as.numeric)))
    idx <- which(temp == 0)
    if (length(idx)) {
      outliers <- data[idx, ]
      # filename_outliers <- "exclusive_proteins_control"
      filename_outliers <-
        paste0("exclusive_", paste0(type_molecule, 's'), "_control")
      data <- data[-idx,] # removing indexed rows
    }

    writeLines(
      paste(
        'Removing',
        paste0(type_molecule, 's'),
        'with all zeros in control replicates and
      all/some values in treatment replicates'
      )
    )
    ## Filter out proteins/peptides with all zeros in control
    ## (values in treatment don't care)
    ## see followig example
    ## treat1 treat2 treat3 cont1 cont2 cont3 uniprot gene_names
    ## ---------------------------------------------------------
    ## 2810900  0      0      0     0     0    Q02888   INA17
    temp <-
      as.matrix(rowSums(apply(data[, (rep_treats + 1):(rep_conts + rep_treats)], 2, as.numeric)))

    idx <- which(temp == 0)
    if (length(idx)) {
      outliers_control <- data[idx, ]
      # filename_outliers_control <- "exclusive_proteins_treatment"
      filename_outliers_control <-
        paste0("exclusive_", paste0(type_molecule, 's'), "_treatment")
      data <- data[-idx,] # removing indexed rows
    }

    ## Extract only those proteins/peptides that has intensity
    ## values in k out of N replicates in each group
    nz_rep_cont <- get_k_out_of_N(rep_conts, control, type_molecule)
    nz_rep_treat <-
      get_k_out_of_N(rep_treats, treatment, type_molecule)

    writeLines(
      paste(
        'Extracting only those',
        paste0(type_molecule, 's'),
        'for LIMMA analysis that has
      intensity values in k out of N replicates in each group'
      )
    )

    idx_nz_treatment <-
      which(rowSums(data[, 1:rep_treats] != 0) >= nz_rep_treat)
    idx_nz_control <-
      which(rowSums(data[, (rep_treats + 1):(rep_conts + rep_treats)] != 0) >= nz_rep_cont)
    idx_nz_both <-
      intersect(idx_nz_control, idx_nz_treatment)
    data <- data[idx_nz_both, ]

    if (!exists('filename_outliers_control')) {
      filename_outliers_control <- 'EMPTY'
      outliers_control <- 'EMPTY'
    }

    if (!exists('filename_outliers')) {
      filename_outliers <- 'EMPTY'
      outliers <- 'EMPTY'
    }

    return(
      list(
        'data' = data,
        'filename_outliers_control' = filename_outliers_control,
        'filename_outliers' = filename_outliers,
        'outliers' = outliers,
        'outliers_control' = outliers_control
      )
    )
  }
################################################################################
# remove_exclusives <-
#   function(data,
#            rep_treats,
#            rep_conts,
#            control,
#            treatment,
#            type_molecule) {
#     writeLines(
#       'Removing proteins with all zeros in treatment replicates and
#       all/some values in control replicates'
#     )
#     ## Filter out proteins with all zeros in treatment
#     ## (values in control don't care)
#     ## see followig example
#     ## treat1 treat2 treat3 cont1 cont2 cont3 uniprot gene_names
#     ## ---------------------------------------------------------
#     ##  0       0       0     0  2810900  0    Q02888   INA17
#     temp <-
#       as.matrix(rowSums(apply(data[, 1:rep_treats], 2, as.numeric)))
#     idx <- which(temp == 0)
#     if (length(idx)) {
#       outliers <- data[idx, ]
#       filename_outliers <- "exclusive_proteins_control"
#       data <- data[-idx,] # removing indexed rows
#     }
#
#     writeLines(
#       'Removing proteins with all zeros in control replicates and
#       all/some values in treatment replicates'
#     )
#     ## Filter out proteins with all zeros in control
#     ## (values in treatment don't care)
#     ## see followig example
#     ## treat1 treat2 treat3 cont1 cont2 cont3 uniprot gene_names
#     ## ---------------------------------------------------------
#     ## 2810900  0      0      0     0     0    Q02888   INA17
#     temp <-
#       as.matrix(rowSums(apply(data[, (rep_treats + 1):(rep_conts + rep_treats)], 2, as.numeric)))
#
#     idx <- which(temp == 0)
#     if (length(idx)) {
#       outliers_control <- data[idx, ]
#       filename_outliers_control <-
#         "exclusive_proteins_treatment"
#       data <- data[-idx,] # removing indexed rows
#     }
#
#     ## Extract only those proteins that has intensity
#     ## values in k out of N replicates in each group
#     nz_rep_cont <- get_k_out_of_N(rep_conts, control)
#     nz_rep_treat <- get_k_out_of_N(rep_treats, treatment)
#     writeLines(
#       'Extracting only those proteins for LIMMA analysis that has
#       intensity values in k out of N replicates in each group'
#     )
#
#     idx_nz_treatment <-
#       which(rowSums(data[, 1:rep_treats] != 0) >= nz_rep_treat)
#     idx_nz_control <-
#       which(rowSums(data[, (rep_treats + 1):(rep_conts + rep_treats)] != 0) >= nz_rep_cont)
#     idx_nz_both <-
#       intersect(idx_nz_control, idx_nz_treatment)
#     data <- data[idx_nz_both, ]
#
#     if (!exists('filename_outliers_control')) {
#       filename_outliers_control <- 'EMPTY'
#       outliers_control <- 'EMPTY'
#     }
#
#     if (!exists('filename_outliers')) {
#       filename_outliers <- 'EMPTY'
#       outliers <- 'EMPTY'
#     }
#
#     return(
#       list(
#         'data' = data,
#         'filename_outliers_control' = filename_outliers_control,
#         'filename_outliers' = filename_outliers,
#         'outliers' = outliers,
#         'outliers_control' = outliers_control
#       )
#     )
#   }
################################################################################
#' Peptide LIMMA
#' @param mq_data MaxQuant output peptides.txt
#' @param norm_method method to normalize data
#' @param fdr false discovery rate
#' @param remove_carbamidomethylation remove the carbamidomethylation (if any) on cysteines
#' @param subDir name of the result folder
#' @param output_folder_path path where the result folder is kept
#' default location is present working directory
peptide_limma <- function(mq_data,
                          norm_method,
                          fdr,
                          remove_carbamidomethylation,
                          subDir,
                          output_folder_path) {
  ## Set norm_method to NULL if missing
  if (missing(norm_method)) {
    norm_method <- 0
  }

  ## Set fdr to 0.05 if missing
  if (missing(fdr)) {
    fdr <- 0.05
  }

  ## Extract uniprot, protein_names and gene_names
  uniprot <- mq_data$`Leading razor protein`
  gene_names <- mq_data$`Gene names`
  protein_names <- mq_data$`Protein names`

  ## Remove carbamidomethyl modification mass from peptide mass
  if (remove_carbamidomethylation)  mq_data <- remove_carbamidomethyl_modifications (mq_data)
  mass <- as.matrix(mq_data$Mass)

  ## Extract required data for Limma
  treatment <-
    readline(
      paste(
        'Enter treatment name(case insensitive)',
        'as it appeared in the iBAQ/LFQ/Intensity column = '
      )
    )
  control <-
    readline(
      paste(
        'Enter control name(case insensitive)',
        'as it appeared in the LFQ/iBAQ/Intensity columns = '
      )
    )
  fc_threshold <-
    readfloat("Enter the fold change cut off = ")

  temp <-
    dplyr::select(mq_data,
                  dplyr::matches(paste('^.*', "Intensity", '.*$', sep = '')))
  treatment_reps <-
    data_sanity_check(temp, 'treatment', treatment)
  control_reps <-
    data_sanity_check(temp, 'control', control)
  data <-
    cbind(
      treatment_reps,
      control_reps,
      mass,
      uniprot,
      gene_names,
      protein_names,
      dplyr::select(mq_data, dplyr::matches("^id$"))
      # dplyr::select(mq_data, dplyr::matches("C Count"))
    )

  print(head(data))
  rep_treats <- ncol(treatment_reps)
  rep_conts <- ncol(control_reps)

  writeLines('Removing peptides with zero intensity in all the replicates')

  ## Filter out out Blank rows,
  ## i.e. peptides with all zeros in treatment and control,
  ## see followig example
  ## treat1 treat2 treat3 cont1 cont2 cont3 uniprot gene_names
  ## ---------------------------------------------------------
  ##  0       0       0     0     0     0    Q02888   INA17
  temp <-
    as.matrix(rowSums(apply(data[, 1:(rep_treats + rep_conts)], 2, as.numeric)))
  idx <- which(temp == 0)
  if (length(idx)) {
    data <- data[-idx,] # removing blank rows
  }

  ## Choose if you want to remove outliers before analysis
  flag <- readline(
    cat(
      '\nEnter 1: if you want to remove exclusively enriched peptides before analysis\n',
      '\bEnter 0: if you want to use full data for analysis\n',
      '\b(for definition of "exclusively enriched proteins/peptides" see ImShot documentation/manuscript)= '
    )
  )
  flag <- as.integer(flag)

  ## Sanity check flag values
  if (!length(which(c(0, 1) == flag))) {
    stop('WRONG value in flag: it can hold either 0 or 1')
  }

  if (flag) {
    filtered_data <-
      remove_exclusives(data, rep_treats, rep_conts, control, treatment, "peptide")
    data <- filtered_data$data

    if (filtered_data$filename_outliers != "EMPTY") {
      filename_outliers <- filtered_data$filename_outliers
      outliers <- filtered_data$outliers
    }

    if (filtered_data$filename_outliers_control != "EMPTY") {
      filename_outliers_control <- filtered_data$filename_outliers_control
      outliers_control <- filtered_data$outliers_control
    }
  }

  ## Impute data
  writeLines('Imputing missing values')
  imputation_method <-
    c(
      'impSeqRob',
      'impSeq',
      'missForest',
      'imputePCA',
      'ppca',
      'MIPCA',
      'bpca',
      'SVDImpute',
      'kNNImpute',
      'tiny'
    )
  print (imputation_method)
  print(
    "select an imputation mehtod (case sensitive) from the above list, to know more about the algorithms see supplement"
  )
  impute_method <-
    readline("Now enter the name of an imputation algorithm (case sensitive) from the above list = ")
  while (!impute_method %in% imputation_method) {
    print("Incorrect imputation algorithm, check case, spelling and try again...")
    print (imputation_method)
    impute_method <-
      readline("Now enter the name of an imputation algorithm (case sensitive) from the above list = ")
  }
  data_limma <-
    log2(as.matrix(data[c(1:(rep_treats + rep_conts))]))
  data_limma[is.infinite(data_limma)] <- NA
  data_limma <- impute_missing_values(data_limma, impute_method)

  if (is.null(data_limma)) {
    stop(paste(
      impute_method,
      "method resulted in null matrix, execution is terminated..."
    ))
  }

  # nan_idx <- which(is.na(data_limma))
  # fit <- MASS::fitdistr(c(na.exclude(data_limma)), "normal")
  # mu <- as.double(fit$estimate[1])
  # sigma <- as.double(fit$estimate[2])
  # sigma_cutoff <- 6
  # new_width_cutoff <- 0.3
  # downshift <- 1.8
  # width <- sigma_cutoff * sigma
  # new_width <- width * new_width_cutoff
  # new_sigma <- new_width / sigma_cutoff
  # new_mean <- mu - downshift * sigma
  # imputed_vals_my = rnorm(length(nan_idx), new_mean, new_sigma)
  # data_limma[nan_idx] <- imputed_vals_my

  ## Median Normalization Module
  if (norm_method == 1) {
    col_med <- matrixStats::colMedians(data_limma)
    med_mat <- matlab::repmat(col_med, nrow(data_limma), 1)
    data_limma <- data_limma - med_mat
  } else if (norm_method == 2) {
    data_limma <- median_normalization(data_limma)
  }
  writeLines('Calling LIMMA module')

  ## Limma main code
  design <-
    stats::model.matrix( ~ factor(c(rep(2, rep_treats), rep(1, rep_conts))))
  colnames(design) <- c("Intercept", "Diff")
  res.eb <- eb.fit(data_limma, design, data$gene_names)
  Sig_FC_idx <-
    union(which(res.eb$logFC < (-fc_threshold)),
          which(res.eb$logFC > fc_threshold))
  Sig_Pval_mod_idx <- which(res.eb$q.mod < fdr)
  Sig_Pval_ord_idx <- which(res.eb$q.ord < fdr)
  Sig_mod_idx <-  intersect(Sig_FC_idx, Sig_Pval_mod_idx)
  Sig_ord_idx <-  intersect(Sig_FC_idx, Sig_Pval_ord_idx)
  categ_Ord <-
    rep(c("Not Significant"), times = length(data$gene_names))
  categ_Mod <- categ_Ord
  if (length(Sig_mod_idx) != 0) {
    categ_Mod[Sig_mod_idx] <- "Significant"
  }
  if (length(Sig_ord_idx) != 0) {
    categ_Ord[Sig_ord_idx] <- "Significant"
  }
  dat <-
    cbind(
      res.eb,
      categ_Ord,
      categ_Mod,
      NegLogPvalMod = (-log10(res.eb$p.mod)),
      NegLogPvalOrd = (-log10(res.eb$p.ord))
    )
  dat <- dplyr::select(dat, -dplyr::matches("^gene$"))
  # C_Count <- data$`C Count`

  ## Save the data file
  final_data <-
    cbind(
      data$mass,
      data$uniprot,
      data$protein_names,
      data$gene_names,
      data[, 1:rep_treats],
      as.matrix(rowMeans(as.matrix(data[, 1:rep_treats]))),
      as.matrix(matrixStats::rowMedians(as.matrix(data[, 1:rep_treats]))),
      data[, (rep_treats + 1):(rep_treats + rep_conts)],
      as.matrix(rowMeans(as.matrix(data[, (rep_treats + 1):(rep_treats + rep_conts)]))),
      as.matrix(matrixStats::rowMedians(as.matrix(data[, (rep_treats + 1):(rep_treats + rep_conts)]))),
      dat
      # C_Count
    )

  colnames(final_data)[1] <- c("mass")
  colnames(final_data)[2] <- c("uniprot")
  colnames(final_data)[3] <- c("protein_names")
  colnames(final_data)[4] <- c("gene_names")
  colnames(final_data)[8] <-
    c(paste('Mean_', treatment, sep = ''))
  colnames(final_data)[9] <-
    c(paste('Median_', treatment, sep = ''))
  colnames(final_data)[13] <- c(paste('Mean_', control, sep = ''))
  colnames(final_data)[14] <-
    c(paste('Median_', control, sep = ''))

  filename_final_data <- 'final_data'

  ## Create plotly object and save plot as html
  filename_mod <- 'modertaed_t-test_plot'
  filename_ord <- 't-test_plot'

  ## Cretae a subdirectory in the output_folder_path
  plot_dir <- file.path(output_folder_path, subDir)
  dir.create(plot_dir, showWarnings = FALSE)

  ## Further create sub folder with timestamp to save plots and data
  timestamp_dir <-
    paste0(plot_dir, '/Peptide_', format(Sys.time(), "%Y%m%d_%H%M%S"))
  dir.create(timestamp_dir, showWarnings = FALSE)
  plot_dir <- timestamp_dir

  writeLines('Writing plot files')

  ## Call Plotly image plotter
  display_plotly_figs(final_data,
                      fc_threshold,
                      filename_mod,
                      filename_ord,
                      plot_dir)

  writeLines('Writing data files')

  if (exists('final_data')) {
    writexl::write_xlsx(
      final_data,
      paste0(plot_dir,
             '/',
             filename_final_data,
             '.xlsx'),
      col_names = TRUE,
      format_headers = TRUE
    )
    writeLines('Final data is written successfully')
  }

  if (exists('filename_outliers')) {
    writexl::write_xlsx(
      outliers,
      paste0(plot_dir,
             '/',
             filename_outliers,
             '.xlsx'),
      col_names = TRUE,
      format_headers = TRUE
    )
    writeLines('filename_outliers is written successfully')
  }

  if (exists('filename_outliers_control')) {
    writexl::write_xlsx(
      outliers_control,
      paste0(plot_dir,
             '/',
             filename_outliers_control,
             '.xlsx'),
      col_names = TRUE,
      format_headers = TRUE
    )
    writeLines('filename_outliers_control is written successfully')
  }

  ############Further processing with final_data#########################
  idx_sig_enrich_treatment <-
    intersect(which(final_data$p.mod < 0.05),
              which(final_data$logFC > fc_threshold))
  idx_sig_enrich_control <-
    intersect(which(final_data$p.mod < 0.05),
              which(final_data$logFC < -fc_threshold))

  final_data_treatment <-
    cbind(final_data[idx_sig_enrich_treatment, 1:9],
          final_data$logFC[idx_sig_enrich_treatment],
          final_data$p.mod[idx_sig_enrich_treatment])
  colnames(final_data_treatment)[ncol(final_data_treatment) - 1] <-
    c("logFC")
  colnames(final_data_treatment)[ncol(final_data_treatment)] <-
    c("Pvalue_limma")

  writexl::write_xlsx(
    final_data_treatment,
    paste0(
      plot_dir,
      '/',
      'enriched_treatment_statistically_significant',
      '.xlsx'
    ),
    col_names = TRUE,
    format_headers = TRUE
  )

  final_data_control <-
    cbind(final_data[idx_sig_enrich_control, 1:4],
          final_data[idx_sig_enrich_control, 10:15],
          final_data$p.mod[idx_sig_enrich_control])

  colnames(final_data_control)[ncol(final_data_control)] <-
    c("Pvalue_limma")

  writexl::write_xlsx(
    final_data_control,
    paste0(
      plot_dir,
      '/',
      'enriched_control_statistically_significant',
      '.xlsx'
    ),
    col_names = TRUE,
    format_headers = TRUE
  )

  ##Extract all peptdes with logFC > fc_threshold,  don't care Pvalue##
  idx_sig_enrich_treatment <-
    which(final_data$logFC > fc_threshold)
  final_data_treatment_Pval_DC <-
    cbind(final_data[idx_sig_enrich_treatment, 1:9],
          final_data$logFC[idx_sig_enrich_treatment],
          final_data$p.mod[idx_sig_enrich_treatment])
  colnames(final_data_treatment_Pval_DC)[ncol(final_data_treatment_Pval_DC) -
                                           1] <- c("logFC")
  colnames(final_data_treatment_Pval_DC)[ncol(final_data_treatment_Pval_DC)] <-
    c("Pvalue_limma")

  writexl::write_xlsx(
    final_data_treatment_Pval_DC,
    paste0(
      plot_dir,
      '/',
      'enriched_treatment_FC_grt_fc_cutoff_Pval_DC',
      '.xlsx'
    ),
    col_names = TRUE,
    format_headers = TRUE
  )
  ##Extract all peptdes with logFC < -fc_threshold,  don't care Pvalue##
  idx_sig_enrich_control <-
    which(final_data$logFC < -fc_threshold)
  final_data_control_Pval_DC <-
    cbind(final_data[idx_sig_enrich_control, 1:4],
          final_data[idx_sig_enrich_control, 10:15],
          final_data$p.mod[idx_sig_enrich_control])
  colnames(final_data_control_Pval_DC)[ncol(final_data_control_Pval_DC)] <-
    c("Pvalue_limma")

  writexl::write_xlsx(
    final_data_control_Pval_DC,
    paste0(
      plot_dir,
      '/',
      'enriched_control_FC_less_-fc_cutoff_Pval_DC',
      '.xlsx'
    ),
    col_names = TRUE,
    format_headers = TRUE
  )

  ##Extract all peptdes with logFC > 0,  don't care Pvalue##
  if (exists('final_data')) {
    idx_sig_enrich_treatment <- which(final_data$logFC > 0)
    final_data_treatment_FC_grt_0_Pval_DC <-
      cbind(final_data[idx_sig_enrich_treatment, 1:9],
            final_data$logFC[idx_sig_enrich_treatment],
            final_data$p.mod[idx_sig_enrich_treatment])

    cols <- ncol(final_data_treatment_FC_grt_0_Pval_DC)
    colnames(final_data_treatment_FC_grt_0_Pval_DC)[(cols - 1):cols] <-
      c("logFC", "Pvalue_limma")

    writexl::write_xlsx(
      final_data_treatment_FC_grt_0_Pval_DC,
      paste0(
        plot_dir,
        '/',
        'enriched_treatment_FC_grt_0_Pval_DC',
        '.xlsx'
      ),
      col_names = TRUE,
      format_headers = TRUE
    )

    #######Extract all peptdes with logFC < 0,  don't care Pvalue########
    idx_sig_enrich_control <- which(final_data$logFC < 0)
    final_data_control_FC_less_0_Pval_DC <-
      cbind(final_data[idx_sig_enrich_control, 1:4],
            final_data[idx_sig_enrich_control, 10:15],
            final_data$p.mod[idx_sig_enrich_control])
    cols <- ncol(final_data_control_FC_less_0_Pval_DC)
    colnames(final_data_control_FC_less_0_Pval_DC)[cols] <-
      c("Pvalue_limma")

    writexl::write_xlsx(
      final_data_control_FC_less_0_Pval_DC,
      paste0(
        plot_dir,
        '/',
        'enriched_control_FC_less_0_Pval_DC',
        '.xlsx'
      ),
      col_names = TRUE,
      format_headers = TRUE
    )
  }
}
################################################################################
# peptide_limma <- function(mq_data,
#                           subDir,
#                           output_folder_path) {
#   ## Extract uniprot, protein_names and gene_names
#   uniprot <- mq_data$`Leading razor protein`
#   gene_names <- mq_data$`Gene names`
#   protein_names <- mq_data$`Protein names`
#   mass <- as.matrix(mq_data$Mass)
#
#   ## Extract required data for Limma
#   treatment <-
#     readline(
#       paste(
#         'Enter treatment name(case insensitive)',
#         'as it appeared in the iBAQ/LFQ column = '
#       )
#     )
#   control <-
#     readline(
#       paste(
#         'Enter control name(case insensitive)',
#         'as it appeared in the LFQ/iBAQ/Intensity columns = '
#       )
#     )
#   fc_threshold <-
#     readfloat("Enter the fold change cut off = ")
#
#   temp <-
#     dplyr::select(mq_data,
#                   dplyr::matches(paste('^.*', "Intensity", '.*$', sep = '')))
#   treatment_reps <-
#     data_sanity_check(temp, 'treatment', treatment)
#   control_reps <-
#     data_sanity_check(temp, 'control', control)
#   data <-
#     cbind(
#       treatment_reps,
#       control_reps,
#       mass,
#       uniprot,
#       gene_names,
#       protein_names,
#       dplyr::select(mq_data, dplyr::matches("^id$"))
#     )
#
#   print(head(data))
#   rep_treats <- ncol(treatment_reps)
#   rep_conts <- ncol(control_reps)
#
#
#   writeLines('Removing peptides with zero intensity in all the replicates')
#
#   ## Filter out out Blank rows,
#   ## i.e. peptides with all zeros in treatment and control,
#   ## see followig example
#   ## treat1 treat2 treat3 cont1 cont2 cont3 uniprot gene_names
#   ## ---------------------------------------------------------
#   ##  0       0       0     0     0     0    Q02888   INA17
#   temp <-
#     as.matrix(rowSums(apply(data[, 1:(rep_treats + rep_conts)], 2, as.numeric)))
#   idx <- which(temp == 0)
#   if (length(idx)) {
#     data <- data[-idx, ] # removing blank rows
#   }
#
#   writeLines(
#     'Removing peptides with all zeros in treatment replicates and all/some
#     values in control replicates'
#   )
#
#   ## Filter out peptides with all zeros in treatment
#   ## (values in control don't care)
#   ## see followig example
#   ## treat1 treat2 treat3 cont1 cont2 cont3 uniprot gene_names
#   ## ---------------------------------------------------------
#   ##  0       0       0     0  2810900  0    Q02888   INA17
#   temp <-
#     as.matrix(rowSums(apply(data[, 1:rep_treats], 2, as.numeric)))
#   idx <- which(temp == 0)
#   if (length(idx)) {
#     outliers <- data[idx, ]
#     filename_outliers <- "exclusive_peptides_control"
#     data <- data[-idx,] # removing indexed rows
#   }
#
#   writeLines(
#     'Removing peptides with all zeros in control replicates and all/some
#     values in treatment replicates'
#   )
#   ## Filter out proteins with all zeros in control
#   ## (values in treatment don't care)
#   ## see followig example
#   ## treat1 treat2 treat3 cont1 cont2 cont3 uniprot gene_names
#   ## ---------------------------------------------------------
#   ## 2810900  0      0      0     0     0    Q02888   INA17
#   temp <-
#     as.matrix(rowSums(apply(data[, (rep_treats + 1):(rep_conts + rep_treats)],
#                             2,
#                             as.numeric)))
#   idx <- which(temp == 0)
#   if (length(idx)) {
#     outliers_control <- data[idx, ]
#     filename_outliers_control <- "exclusive_peptides_treatment"
#     data <- data[-idx,] # removing indexed rows
#   }
#
#   writeLines(
#     'Extracting only those peptides for LIMMA analysis that has intensity values
#     in 2/3 replicates in each group'
#   )
#
#   ## Extract only those proteins/peptides that has intensity values in
#   ## 2 out of 3 replicates in each group
#   idx_nz_treatment <-
#     which(rowSums(data[, 1:rep_treats] != 0) >= 2)
#   idx_nz_control <-
#     which(rowSums(data[, (rep_treats + 1):(rep_conts + rep_treats)] != 0) >= 2)
#   idx_nz_both <- intersect(idx_nz_control, idx_nz_treatment)
#   data <- data[idx_nz_both, ]
#
#   writeLines('Imputing missing values')
#
#   ## Impute data
#   data_limma <-
#     log2(as.matrix(data[c(1:(rep_treats + rep_conts))]))
#   data_limma[is.infinite(data_limma)] <- NA
#   nan_idx <- which(is.na(data_limma))
#   fit <- MASS::fitdistr(c(na.exclude(data_limma)), "normal")
#   mu <- as.double(fit$estimate[1])
#   sigma <- as.double(fit$estimate[2])
#   sigma_cutoff <- 6
#   new_width_cutoff <- 0.3
#   downshift <- 1.8
#   width <- sigma_cutoff * sigma
#   new_width <- width * new_width_cutoff
#   new_sigma <- new_width / sigma_cutoff
#   new_mean <- mu - downshift * sigma
#   imputed_vals_my = rnorm(length(nan_idx), new_mean, new_sigma)
#   data_limma[nan_idx] <- imputed_vals_my
#
#   ## Median Normalization Module
#   normalize <-
#     readinteger("Enter 1, if you want median normalized data, else enter any positive number = ")
#   if (normalize == 1) {
#     col_med <- matrixStats::colMedians(data_limma)
#     med_mat <- matlab::repmat(col_med, nrow(data_limma), 1)
#     data_limma <- data_limma - med_mat
#     temp <-
#       matlab::reshape(data_limma, nrow(data_limma) * ncol(data_limma), 1)
#   }
#   writeLines('Calling LIMMA module')
#
#   ## Limma main code
#   design <-
#     stats::model.matrix(~ factor(c(rep(2, rep_treats), rep(1, rep_conts))))
#   colnames(design) <- c("Intercept", "Diff")
#   res.eb <- eb.fit(data_limma, design, data$gene_names)
#   Sig_FC_idx <-
#     union(which(res.eb$logFC < (-fc_threshold)),
#           which(res.eb$logFC > fc_threshold))
#   Sig_Pval_mod_idx <- which(res.eb$p.mod < 0.05)
#   Sig_Pval_ord_idx <- which(res.eb$p.ord < 0.05)
#   Sig_mod_idx <-  intersect(Sig_FC_idx, Sig_Pval_mod_idx)
#   Sig_ord_idx <-  intersect(Sig_FC_idx, Sig_Pval_ord_idx)
#   categ_Ord <-
#     rep(c("Not Significant"), times = length(data$gene_names))
#   categ_Mod <- categ_Ord
#   categ_Mod[Sig_mod_idx] <- "Significant"
#   categ_Ord[Sig_ord_idx] <- "Significant"
#   dat <-
#     cbind(
#       res.eb,
#       categ_Ord,
#       categ_Mod,
#       NegLogPvalMod = (-log10(res.eb$p.mod)),
#       NegLogPvalOrd = (-log10(res.eb$p.ord))
#     )
#   dat <- dplyr::select(dat,-dplyr::matches("^gene$"))
#
#   ## Save the data file
#   final_data <-
#     cbind(
#       data$mass,
#       data$uniprot,
#       data$protein_names,
#       data$gene_names,
#       data[, 1:rep_treats],
#       as.matrix(rowMeans(as.matrix(data[, 1:rep_treats]))),
#       as.matrix(matrixStats::rowMedians(as.matrix(data[, 1:rep_treats]))),
#       data[, (rep_treats + 1):(rep_treats + rep_conts)],
#       as.matrix(rowMeans(as.matrix(data[, (rep_treats + 1):(rep_treats +
#                                                               rep_conts)]))),
#       as.matrix(matrixStats::rowMedians(as.matrix(data[, (rep_treats + 1):(rep_treats + rep_conts)]))),
#       dat
#     )
#
#   colnames(final_data)[1] <- c("mass")
#   colnames(final_data)[2] <- c("uniprot")
#   colnames(final_data)[3] <- c("protein_names")
#   colnames(final_data)[4] <- c("gene_names")
#   colnames(final_data)[8] <-
#     c(paste('Mean_', treatment, sep = ''))
#   colnames(final_data)[9] <-
#     c(paste('Median_', treatment, sep = ''))
#   colnames(final_data)[13] <- c(paste('Mean_', control, sep = ''))
#   colnames(final_data)[14] <-
#     c(paste('Median_', control, sep = ''))
#
#   filename_final_data <- 'final_data'
#
#   ## Create plotly object and save plot as html
#   filename_mod <- 'modertaed_t-test_plot'
#   filename_ord <- 't-test_plot'
#
#   ## Cretae a subdirectory in the output_folder_path
#   plot_dir <- file.path(output_folder_path, subDir)
#   dir.create(plot_dir, showWarnings = FALSE)
#
#   ## Further create sub folder with timestamp to save plots and data
#   timestamp_dir <-
#     paste0(plot_dir, '/Peptide_', format(Sys.time(), "%Y%m%d_%H%M%S"))
#   dir.create(timestamp_dir, showWarnings = FALSE)
#   plot_dir <- timestamp_dir
#
#   writeLines('Writing plot files')
#
#   ## Call Plotly image plotter
#   display_plotly_figs(final_data,
#                       fc_threshold,
#                       filename_mod,
#                       filename_ord,
#                       plot_dir)
#
#   writeLines('Writing data files')
#
#   ## Write final data
#   # write.table(
#   #   final_data,
#   #   paste(plot_dir,
#   #         '/',
#   #         filename_final_data,
#   #         '.tsv',
#   #         sep = ''),
#   #   sep = '\t',
#   #   row.names = FALSE,
#   #   col.names = TRUE
#   # )
#   writexl::write_xlsx(
#     final_data,
#     paste0(plot_dir,
#            '/',
#            filename_final_data,
#            '.xlsx'),
#     col_names = TRUE,
#     format_headers = TRUE
#   )
#
#   ## Write outliers in treatment
#   # write.table(
#   #   outliers,
#   #   paste(plot_dir,
#   #         '/',
#   #         filename_outliers,
#   #         '.tsv',
#   #         sep = ''),
#   #   sep = '\t',
#   #   row.names = FALSE,
#   #   col.names = TRUE
#   # )
#   writexl::write_xlsx(
#     outliers,
#     paste0(plot_dir,
#            '/',
#            filename_outliers,
#            '.xlsx'),
#     col_names = TRUE,
#     format_headers = TRUE
#   )
#
#   ## Write outliers in control
#   # write.table(
#   #   outliers_control,
#   #   paste(plot_dir,
#   #         '/',
#   #         filename_outliers_control,
#   #         '.tsv',
#   #         sep = ''),
#   #   sep = '\t',
#   #   row.names = FALSE,
#   #   col.names = TRUE
#   # )
#   writexl::write_xlsx(
#     outliers_control,
#     paste0(plot_dir,
#            '/',
#            filename_outliers_control,
#            '.xlsx'),
#     col_names = TRUE,
#     format_headers = TRUE
#   )
#
#   ############Further processing with final_data#########################
#   idx_sig_enrich_treatment <-
#     intersect(which(final_data$p.mod < 0.05),
#               which(final_data$logFC > fc_threshold))
#   idx_sig_enrich_control <-
#     intersect(which(final_data$p.mod < 0.05),
#               which(final_data$logFC < -fc_threshold))
#
#   final_data_treatment <-
#     cbind(final_data[idx_sig_enrich_treatment, 1:9],
#           final_data$logFC[idx_sig_enrich_treatment],
#           final_data$p.mod[idx_sig_enrich_treatment])
#   colnames(final_data_treatment)[ncol(final_data_treatment) - 1] <-
#     c("logFC")
#   colnames(final_data_treatment)[ncol(final_data_treatment)] <-
#     c("Pvalue_limma")
#
#   # write.table(
#   #   final_data_treatment,
#   #   paste(
#   #     plot_dir,
#   #     '/',
#   #     'enriched_treatment_statistically_significant',
#   #     '.txt',
#   #     sep = ''
#   #   ),
#   #   sep = '\t',
#   #   row.names = FALSE,
#   #   col.names = TRUE
#   # )
#   writexl::write_xlsx(
#     final_data_treatment,
#     paste0(
#       plot_dir,
#       '/',
#       'enriched_treatment_statistically_significant',
#       '.xlsx'
#     ),
#     col_names = TRUE,
#     format_headers = TRUE
#   )
#
#   final_data_control <-
#     cbind(final_data[idx_sig_enrich_control, 1:4],
#           final_data[idx_sig_enrich_control, 10:15],
#           final_data$p.mod[idx_sig_enrich_control])
#
#   colnames(final_data_control)[ncol(final_data_control)] <-
#     c("Pvalue_limma")
#
#   # write.table(
#   #   final_data_control,
#   #   paste(
#   #     plot_dir,
#   #     '/',
#   #     'enriched_control_statistically_significant',
#   #     '.txt',
#   #     sep = ''
#   #   ),
#   #   sep = '\t',
#   #   row.names = FALSE,
#   #   col.names = TRUE
#   # )
#   writexl::write_xlsx(
#     final_data_control,
#     paste0(
#       plot_dir,
#       '/',
#       'enriched_control_statistically_significant',
#       '.xlsx'
#     ),
#     col_names = TRUE,
#     format_headers = TRUE
#   )
#
#   ##Extract all peptdes with logFC > fc_threshold,  don't care Pvalue##
#   idx_sig_enrich_treatment <-
#     which(final_data$logFC > fc_threshold)
#   final_data_treatment_Pval_DC <-
#     cbind(final_data[idx_sig_enrich_treatment, 1:9],
#           final_data$logFC[idx_sig_enrich_treatment],
#           final_data$p.mod[idx_sig_enrich_treatment])
#   colnames(final_data_treatment_Pval_DC)[ncol(final_data_treatment_Pval_DC) -
#                                            1] <- c("logFC")
#   colnames(final_data_treatment_Pval_DC)[ncol(final_data_treatment_Pval_DC)] <-
#     c("Pvalue_limma")
#
#   # write.table(
#   #   final_data_treatment_Pval_DC,
#   #   paste(
#   #     plot_dir,
#   #     '/',
#   #     'enriched_treatment_FC_grt_fc_cutoff_Pval_DC',
#   #     '.txt',
#   #     sep = ''
#   #   ),
#   #   sep = '\t',
#   #   row.names = FALSE,
#   #   col.names = TRUE
#   # )
#   writexl::write_xlsx(
#     final_data_treatment_Pval_DC,
#     paste0(
#       plot_dir,
#       '/',
#       'enriched_treatment_FC_grt_fc_cutoff_Pval_DC',
#       '.xlsx'
#     ),
#     col_names = TRUE,
#     format_headers = TRUE
#   )
#   ##Extract all peptdes with logFC < -fc_threshold,  don't care Pvalue##
#   idx_sig_enrich_control <-
#     which(final_data$logFC < -fc_threshold)
#   final_data_control_Pval_DC <-
#     cbind(final_data[idx_sig_enrich_control, 1:4],
#           final_data[idx_sig_enrich_control, 10:15],
#           final_data$p.mod[idx_sig_enrich_control])
#   colnames(final_data_control_Pval_DC)[ncol(final_data_control_Pval_DC)] <-
#     c("Pvalue_limma")
#
#   # write.table(
#   #   final_data_control_Pval_DC,
#   #   paste(
#   #     plot_dir,
#   #     '/',
#   #     'enriched_control_FC_less_-fc_cutoff_Pval_DC',
#   #     '.txt',
#   #     sep = ''
#   #   ),
#   #   sep = '\t',
#   #   row.names = FALSE,
#   #   col.names = TRUE
#   # )
#   writexl::write_xlsx(
#     final_data_control_Pval_DC,
#     paste0(
#       plot_dir,
#       '/',
#       'enriched_control_FC_less_-fc_cutoff_Pval_DC',
#       '.xlsx'
#     ),
#     col_names = TRUE,
#     format_headers = TRUE
#   )
#
#   ##Extract all peptdes with logFC > 0,  don't care Pvalue##
#   idx_sig_enrich_treatment <- which(final_data$logFC > 0)
#   final_data_treatment_FC_grt_0_Pval_DC <-
#     cbind(final_data[idx_sig_enrich_treatment, 1:9],
#           final_data$logFC[idx_sig_enrich_treatment],
#           final_data$p.mod[idx_sig_enrich_treatment])
#
#   cols <- ncol(final_data_treatment_FC_grt_0_Pval_DC)
#   colnames(final_data_treatment_FC_grt_0_Pval_DC)[(cols - 1):cols] <-
#     c("logFC", "Pvalue_limma")
#   # write.table(
#   #   final_data_treatment_FC_grt_0_Pval_DC,
#   #   paste(
#   #     plot_dir,
#   #     '/',
#   #     'enriched_treatment_FC_grt_0_Pval_DC',
#   #     '.txt',
#   #     sep = ''
#   #   ),
#   #   sep = '\t',
#   #   row.names = FALSE,
#   #   col.names = TRUE
#   # )
#   writexl::write_xlsx(
#     final_data_treatment_FC_grt_0_Pval_DC,
#     paste0(
#       plot_dir,
#       '/',
#       'enriched_treatment_FC_grt_0_Pval_DC',
#       '.xlsx'
#     ),
#     col_names = TRUE,
#     format_headers = TRUE
#   )
#
#   #######Extract all peptdes with logFC < 0,  don't care Pvalue########
#   idx_sig_enrich_control <- which(final_data$logFC < 0)
#   final_data_control_FC_less_0_Pval_DC <-
#     cbind(final_data[idx_sig_enrich_control, 1:4],
#           final_data[idx_sig_enrich_control, 10:15],
#           final_data$p.mod[idx_sig_enrich_control])
#   cols <- ncol(final_data_control_FC_less_0_Pval_DC)
#   colnames(final_data_control_FC_less_0_Pval_DC)[cols] <-
#     c("Pvalue_limma")
#
#   # write.table(
#   #   final_data_control_FC_less_0_Pval_DC,
#   #   paste(
#   #     plot_dir,
#   #     '/',
#   #     'enriched_control_FC_less_0_Pval_DC',
#   #     '.txt',
#   #     sep = ''
#   #   ),
#   #   sep = '\t',
#   #   row.names = FALSE,
#   #   col.names = TRUE
#   # )
#   writexl::write_xlsx(
#     final_data_control_FC_less_0_Pval_DC,
#     paste0(
#       plot_dir,
#       '/',
#       'enriched_control_FC_less_0_Pval_DC',
#       '.xlsx'
#     ),
#     col_names = TRUE,
#     format_headers = TRUE
#   )
# }

#' Limma Module
#' @param dat the data matrix containing treatmnet and control replicates
#' @param design the design matrix of the proteomic experiment
#' @param gene list of genes/proteins quantified in a proteomic experiment
eb.fit <- function(dat, design, gene) {
  n <- dim(dat)[1]
  fit <- limma::lmFit(dat, design)
  fit.eb <- limma::eBayes(fit)
  logFC <- fit.eb$coefficients[, 2]
  df.r <- fit.eb$df.residual
  df.0 <- rep(fit.eb$df.prior, n)
  s2.0 <- rep(fit.eb$s2.prior, n)
  s2 <- (fit.eb$sigma) ^ 2
  s2.post <- fit.eb$s2.post
  t.ord <-
    fit.eb$coefficients[, 2] / fit.eb$sigma / fit.eb$stdev.unscaled[, 2]
  t.mod <- fit.eb$t[, 2]
  p.ord <- 2 * pt(-abs(t.ord), fit.eb$df.residual)
  p.mod <- fit.eb$p.value[, 2]
  q.ord <- qvalue::qvalue(p.ord)$q
  q.mod <- qvalue::qvalue(p.mod)$q
  results.eb <-
    data.frame(logFC,
               t.ord,
               t.mod,
               p.ord,
               p.mod,
               q.ord,
               q.mod,
               df.r,
               df.0,
               s2.0,
               s2,
               s2.post,
               gene)
  return(results.eb)
}

readinteger <- function(str)
{
  n <- readline(prompt = str)
  n <- as.integer(n)
  if (is.na(n) || (n <= 0)) {
    writeLines("Enter positive integer only")
    n <- readinteger(str)
  }
  return(n)
}

readfloat <- function(str)
{
  n <- readline(prompt = str)
  n <- as.double(n)
  if (is.na(n) || (n <= 0)) {
    writeLines("Enter a positive number only")
    n <- readfloat(str)
  }
  return(n)
}

readfloat_0_1 <- function(str)
{
  n <- readline(prompt = str)
  n <- as.double(n)
  if (is.na(n) || (n <= 0)) {
    writeLines("Enter a number>0 & <=1, try again")
    n <- readfloat(str)
  } else if (n > 1) {
    writeLines("Enter a number>0 & <=1, try again")
  }
  return(n)
}

readinteger_binary <- function(str)
{
  n <- readline(prompt = str)
  n <- as.integer(n)
  if (is.na(n) || (n < 0) || (n > 1)) {
    writeLines("Enter positive integer only")
    n <- readinteger_binary(str)
  }
  return(n)
}

data_sanity_check <- function(temp, exp_type, grp_name) {
  exp_type_reps <-
    dplyr::select(temp, dplyr::matches(paste('^.*', grp_name, '.*$', sep = '')))
  row <- nrow(exp_type_reps)
  col <- ncol(exp_type_reps)
  if (!row * col ||
      suppressWarnings(!is.na(as.integer(grp_name)))) {
    cat('Check', exp_type, 'name and enter correct one\n')
    grp_name <-
      readline(
        cat(
          'Enter',
          exp_type,
          'name(case insensitive) as it appeared
          in the iBAQ/LFQ/Intensity columns= '
        )
      )
    exp_type_reps <-
      data_sanity_check(temp, 'treatment', grp_name)
  }
  return(exp_type_reps)
}

## Sanity check k out of N replicates
get_k_out_of_N <- function(N, exp_type, type_molecule) {
  while (1) {
    k <-
      as.integer(readline(
        paste(
          'Enter k, to select only',
          paste0(type_molecule, "s"),
          'that have k non zero values out of',
          N,
          exp_type,
          'replicates and k>0 = '
        )
      ))
    if (k > N) {
      cat('k must be an integer>0 and <=', N, 'TRY AGAIN\n')
    } else if (k <= 0) {
      cat('k must be an integer>0 and <=', N, 'TRY AGAIN\n')
    } else {
      break
    }
  }
  return(k)
}

## Create ploty plots and save them
display_plotly_figs <-
  function(dat,
           fc_threshold,
           filename_mod,
           filename_ord,
           plot_dir) {
    `%>%` <- plotly::`%>%`
    f <- list(family = "Arial, sans-serif",
              size = 18,
              # color = "#7f7f7f")
              color = 'black')
    f2 <- list(family = "Arial, sans-serif",
               size = 12,
               color = 'black')
    x_axis <- list(
      constraintoward = "bottom",
      title = "log2 fold change",
      titlefont = f,
      showgrid = FALSE,
      showticklabels = TRUE,
      autotick = FALSE,
      ticks = "outside",
      tick0 = 0,
      dtick = 1,
      tickwidth = 1,
      position = -1,
      rangemode = "tozero",
      tickfont = f2
    )
    y_axis <- list(
      title = "-log10 p-value",
      titlefont = f,
      showgrid = FALSE,
      showticklabels = TRUE,
      autotick = FALSE,
      ticks = "outside",
      tick0 = 0,
      dtick = 0.5,
      tickwidth = 1,
      position = -1,
      rangemode = "nonnegative",
      tickfont = f2
    )

    p1 <-
      plotly::plot_ly(
        dat,
        x = ~ logFC,
        y = ~ NegLogPvalMod,
        type = "scatter",
        mode = "markers",
        color = ~ categ_Mod,
        colors = c('#0C4B8E', '#BF382A'),
        hoverinfo = 'text',
        text = ~ paste(
          "uniprot:",
          dat$uniprot,
          # Changed here from gene to uniprot
          "</br>",
          "</br>Protein:",
          dat$protein_names,
          # Added here protein_names
          "</br>",
          "</br>Fold Change:",
          logFC,
          "</br>-log 10[p-value]:",
          NegLogPvalMod
        )
      ) %>%
      plotly::layout(
        # shapes = list(
        #   list(
        #     type = 'line',
        #     x0 = fc_threshold,
        #     x1 = fc_threshold,
        #     y0 = 0,
        #     y1 = ceiling(max(dat$NegLogPvalMod)),
        #     # line = list(dash = 'dot', width = 1)
        #     line = list(
        #       dash = 'dot',
        #       width = 1,
        #       color = 'black'
        #     )
        #   ),
        #   list(
        #     type = 'line',
        #     x0 = -fc_threshold,
        #     x1 = -fc_threshold,
        #     y0 = 0,
        #     y1 = ceiling(max(dat$NegLogPvalMod)),
        #     # line = list(dash = 'dot', width = 1)
        #     line = list(
        #       dash = 'dot',
        #       width = 1,
        #       color = 'black'
        #     )
        #   ),
        #   list(
        #     type = 'line',
        #     x0 = -ceiling(max(abs(min(
        #       dat$logFC
        #     )), max(dat$logFC))),
        #     x1 = ceiling(max(abs(min(
        #       dat$logFC
        #     )), max(dat$logFC))),
        #     y0 = -log10(0.05),
        #     y1 = -log10(0.05),
        #     # line = list(dash = 'dot', width = 1)
        #     line = list(
        #       dash = 'dot',
        #       width = 1,
        #       color = 'black'
        #     )
        #   )
        # ),
        title = list(
          text = paste("volcano plot of moderated p-values"),
          font = f
        ),
        xaxis = x_axis,
        yaxis = y_axis,
        showlegend = TRUE
        # titlefont = f
      )

    p2 <-
      plotly::plot_ly(
        dat,
        x = ~ logFC,
        y = ~ NegLogPvalOrd,
        type = "scatter",
        mode = "markers",
        color = ~ categ_Ord,
        colors = c('#0C4B8E', '#BF382A'),
        hoverinfo = 'text',
        text = ~ paste(
          "uniprot:",
          dat$uniprot,
          # Changed here from gene to uniprot
          "</br>",
          "</br>Protein:",
          dat$protein_names,
          # Added here protein_names
          "</br>",
          "</br>Fold Change:",
          logFC,
          "</br>-log 10[p-value]:",
          NegLogPvalOrd
        )
      ) %>%
      plotly::layout(
        shapes = list(
          list(
            type = 'line',
            x0 = fc_threshold,
            x1 = fc_threshold,
            y0 = 0,
            y1 = ceiling(max(dat$NegLogPvalOrd)),
            # line = list(dash = 'dot', width = 1)
            line = list(
              dash = 'dot',
              width = 1,
              color = 'black'
            )
          ),
          list(
            type = 'line',
            x0 = -fc_threshold,
            x1 = -fc_threshold,
            y0 = 0,
            y1 = ceiling(max(dat$NegLogPvalOrd)),
            # line = list(dash = 'dot', width = 1)
            line = list(
              dash = 'dot',
              width = 1,
              color = 'black'
            )
          ),
          list(
            type = 'line',
            x0 = -ceiling(max(abs(min(
              dat$logFC
            )), max(dat$logFC))),
            x1 = ceiling(max(abs(min(
              dat$logFC
            )), max(dat$logFC))),
            y0 = -log10(0.05),
            y1 = -log10(0.05),
            # line = list(dash = 'dot', width = 1)
            line = list(
              dash = 'dot',
              width = 1,
              color = 'black'
            )
          )
        ),
        title = list(
          text = paste("volcano plot of ordinary p-values"),
          font = f
        ),
        xaxis = x_axis,
        yaxis = y_axis,
        showlegend = TRUE
        # titlefont = f
      )

    ## Save as .html
    htmlwidgets::saveWidget(plotly::as_widget(p1),
                            paste(plot_dir, "/", filename_mod, '.html', sep = ''))
    htmlwidgets::saveWidget(plotly::as_widget(p2),
                            paste(plot_dir, "/", filename_ord, '.html', sep = ''))

    ## Save as .pdf
    # plotly::orca(p1,
    #              file = paste(plot_dir, "/", filename_mod, '.pdf', sep = ''))
    # plotly::orca(p2,
    #              file = paste(plot_dir, "/", filename_ord, '.pdf', sep = ''))
  }
################################################################################
################################################################################
## protein limma
protein_limma <-
  function(mq_data,
           norm_method,
           fdr,
           lfq_or_ibaq,
           subDir,
           output_folder_path) {
    ## Set norm_method to NULL if missing
    if (missing(norm_method)) {
      norm_method <- 0
    }

    ## Set fdr to 0.05 if missing
    if (missing(fdr)) {
      fdr <- 0.05
    }

    ## Cretae a subdirectory in the output_folder_path
    plot_dir <- file.path(output_folder_path, subDir)
    dir.create(plot_dir, showWarnings = FALSE)

    ## Further create sub folder with timestamp to save plots and data
    timestamp_dir <-
      paste0(plot_dir, '/Protein_', format(Sys.time(), "%Y%m%d_%H%M%S"))
    dir.create(timestamp_dir, showWarnings = FALSE)
    plot_dir <- timestamp_dir

    ## Extract uniprot, protein_names and gene_names
    uniprot <- mq_data$`Majority protein IDs`
    gene_names <- mq_data$`Gene names`
    protein_names <- mq_data$`Protein names`

    #Extract required data for Limma
    treatment <-
      readline(
        paste(
          'Enter treatment name(case insensitive)',
          'as it appeared in the iBAQ/LFQ column = '
        )
      )
    control <-
      readline(
        paste(
          'Enter control name(case insensitive)',
          'as it appeared in the iBAQ/LFQ column = '
        )
      )

    if (lfq_or_ibaq == 2) {
      temp <-
        dplyr::select(mq_data, matches(paste('^.*', "ibaq", '.*$', sep = '')))
      treatment_reps <-
        data_sanity_check(temp, 'treatment', treatment)
      control_reps <-
        data_sanity_check(temp, 'control', control)
      data <-
        cbind(
          treatment_reps,
          control_reps,
          dplyr::select(mq_data, matches("^id$")),
          uniprot,
          gene_names,
          protein_names
        )
    } else {
      temp <-
        dplyr::select(mq_data, matches(paste('^.*', "lfq", '.*$', sep = '')))
      treatment_reps <-
        data_sanity_check(temp, 'treatment', treatment)
      control_reps <-
        data_sanity_check(temp, 'control', control)
      data <-
        cbind(
          treatment_reps,
          control_reps,
          dplyr::select(mq_data, matches("^id$")),
          uniprot,
          gene_names,
          protein_names
        )
    }

    rep_treats <- ncol(treatment_reps)
    rep_conts <- ncol(control_reps)
    fc_threshold <-
      readfloat("Enter the fold change cut off = ")
    # print(head(data))

    writeLines('Removing proteins with zero intensity in all the replicates')
    ## Filter out out Blank rows,
    ## i.e. proteins with all zeros in treatment and control,
    ## see followig example
    ## treat1 treat2 treat3 cont1 cont2 cont3 uniprot gene_names
    ## ---------------------------------------------------------
    ##  0       0       0     0     0     0    Q02888   INA17
    temp <-
      as.matrix(rowSums(apply(data[, 1:(rep_treats + rep_conts)], 2, as.numeric)))
    idx <- which(temp == 0)
    if (length(idx)) {
      data <- data[-idx,] # removing blank rows
    }

    ## Choose if you want to remove outliers before analysis
    flag <- readline(
      cat(
        '\nEnter 1: if you want to remove exclusively enriched proteins before analysis\n',
        '\bEnter 0: if you want to use full data for analysis\n',
        '\b(for definition of "exclusively enriched proteins" see ImShot documentation/manuscript)= '
      )
    )
    flag <- as.integer(flag)

    ## Sanity check flag values
    if (!length(which(c(0, 1) == flag))) {
      stop('WRONG value in flag: it can hold either 0 or 1')
    }

    if (flag) {
      filtered_data <-
        remove_exclusives(data, rep_treats, rep_conts, control, treatment, "protein")
      data <- filtered_data$data

      if (filtered_data$filename_outliers != "EMPTY") {
        filename_outliers <- filtered_data$filename_outliers
        outliers <- filtered_data$outliers
      }

      if (filtered_data$filename_outliers_control != "EMPTY") {
        filename_outliers_control <- filtered_data$filename_outliers_control
        outliers_control <- filtered_data$outliers_control
      }
    }

    ## plot histogram of number of non zero intensities across replicates
    ## for each protein
    # temp <- rowSums(data[, 1:rep_treats] != 0)
    # hist_png(temp, 0, paste0(plot_dir, "/histogram_non_zero_", treatment),
    #      "#non zero intensities", "#proteins",
    #      paste("non zero intensities across", treatment, "replicates"))

    # temp <-
    #   rowSums(data[, (rep_treats + 1):(rep_conts + rep_treats)] != 0)
    # hist_png(temp, 0, paste0(plot_dir, "/histogram_non_zero_", control),
    #          "#non zero intensities", "#proteins",
    #          paste("non zero intensities across", control, "replicates"))

    writeLines('Imputing missing values')

    ## Impute data
    writeLines('Imputing missing values')
    imputation_method <-
      c(
        'impSeqRob',
        'impSeq',
        'missForest',
        'imputePCA',
        'ppca',
        'MIPCA',
        'bpca',
        'SVDImpute',
        'kNNImpute',
        'tiny'
      )
    print (imputation_method)
    print(
      "select an imputation mehtod (case sensitive) from the above list, to know more about the algorithms see supplement"
    )
    impute_method <-
      readline("Now enter the name of an imputation algorithm (case sensitive) from the above list = ")
    while (!impute_method %in% imputation_method) {
      print("Incorrect imputation algorithm, check case, spelling and try again...")
      print (imputation_method)
      impute_method <-
        readline("Now enter the name of an imputation algorithm (case sensitive) from the above list = ")
    }
    data_limma <-
      log2(as.matrix(data[c(1:(rep_treats + rep_conts))]))
    data_limma[is.infinite(data_limma)] <- NA
    data_limma <- impute_missing_values(data_limma, impute_method)

    if (is.null(data_limma)) {
      stop(paste(
        impute_method,
        "method resulted in null matrix, execution is terminated..."
      ))
    }
    # data_limma <-
    #   log2(as.matrix(data[c(1:(rep_treats + rep_conts))]))
    # data_limma[is.infinite(data_limma)] <- NA
    # temp <-
    #   matlab::reshape(data_limma, nrow(data_limma) * ncol(data_limma), 1)
    # # hist_png(temp, 1, paste0(plot_dir, "/dist_before_imputation"),
    # #          "log2(intensity)",
    # #          "Frequency",
    # #          "All data: before imputation (nan ignored)")
    # # hist(temp, na.rm = TRUE, xlab = "log2(intensity)", main = "All data: before imputation (nan ignored)")
    # nan_idx <- which(is.na(data_limma))
    # fit <- MASS::fitdistr(c(na.exclude(data_limma)), "normal")
    # mu <- as.double(fit$estimate[1])
    # sigma <- as.double(fit$estimate[2])
    # sigma_cutoff <- 6
    # new_width_cutoff <- 0.3
    # downshift <- 1.8
    # width <- sigma_cutoff * sigma
    # new_width <- width * new_width_cutoff
    # new_sigma <- new_width / sigma_cutoff
    # new_mean <- mu - downshift * sigma
    # imputed_vals_my = rnorm(length(nan_idx), new_mean, new_sigma)
    # # scaling_factor <- readfloat_0_1("Enter a number > 0 and <=1 to scale imputed values = ")
    # scaling_factor <- 1
    # data_limma[nan_idx] <- imputed_vals_my * scaling_factor

    ## Median Normalization Module
    if (norm_method == 1) {
      col_med <- matrixStats::colMedians(data_limma)
      med_mat <- matlab::repmat(col_med, nrow(data_limma), 1)
      data_limma <- data_limma - med_mat
    } else if (norm_method == 2) {
      data_limma <- median_normalization(data_limma)
    }
    writeLines('Calling LIMMA module')

    ## Limma main code
    design <-
      model.matrix( ~ factor(c(rep(2, rep_treats), rep(1, rep_conts))))
    colnames(design) <- c("Intercept", "Diff")
    res.eb <- eb.fit(data_limma, design, data$gene_names)
    Sig_FC_idx <-
      union(which(res.eb$logFC < (-fc_threshold)), which(res.eb$logFC > fc_threshold))
    Sig_Pval_mod_idx <- which(res.eb$p.mod < fdr)
    Sig_Pval_ord_idx <- which(res.eb$p.ord < fdr)
    Sig_mod_idx <-  intersect(Sig_FC_idx, Sig_Pval_mod_idx)
    Sig_ord_idx <-  intersect(Sig_FC_idx, Sig_Pval_ord_idx)
    categ_Ord <-
      rep(c("Not Significant"), times = length(data$gene_names))
    categ_Mod <- categ_Ord
    if (length(Sig_mod_idx) != 0) {
      categ_Mod[Sig_mod_idx] <- "Significant"
    }
    if (length(Sig_ord_idx) != 0) {
      categ_Ord[Sig_ord_idx] <- "Significant"
    }
    dat <-
      cbind(
        res.eb,
        categ_Ord,
        categ_Mod,
        NegLogPvalMod = (-log10(res.eb$p.mod)),
        NegLogPvalOrd = (-log10(res.eb$p.ord))
      )
    dat <- dplyr::select(dat, -matches("^gene$"))

    ## Decorate data file
    final_data <-
      cbind(data$uniprot,
            data$protein_names,
            data$gene_names,
            data[, 1:(rep_treats + rep_conts)],
            dat)
    colnames(final_data)[1] <- c("uniprot")
    colnames(final_data)[2] <- c("protein_names")
    colnames(final_data)[3] <- c("gene_names")
    filename_final_data <- 'final_data'

    ## Name plot files
    filename_mod <- 'modertaed_t-test_plot'
    filename_ord <- 't-test_plot'

    writeLines('Writing plot files')

    ## Create and save plots
    display_plotly_figs(final_data,
                        fc_threshold,
                        filename_mod,
                        filename_ord,
                        plot_dir)

    writeLines('Writing data files')

    ## Write final data
    if (exists('final_data')) {
      writexl::write_xlsx(
        final_data,
        paste0(plot_dir,
               '/',
               filename_final_data,
               '.xlsx'),
        col_names = TRUE,
        format_headers = TRUE
      )
      writeLines('Final data is written successfully')
    }

    ## Write outliers in treatment
    if (exists('filename_outliers')) {
      writexl::write_xlsx(
        outliers,
        paste0(plot_dir,
               '/',
               filename_outliers,
               '.xlsx'),
        col_names = TRUE,
        format_headers = TRUE
      )
      writeLines('filename_outliers is written successfully')
    }

    ## Write outliers in control
    if (exists('filename_outliers_control')) {
      writexl::write_xlsx(
        outliers_control,
        paste0(plot_dir,
               '/',
               filename_outliers_control,
               '.xlsx'),
        col_names = TRUE,
        format_headers = TRUE
      )
      writeLines('filename_outliers_control is written successfully')
    }
    ############ Further processing with final_data #########################
    if (exists('final_data')) {
      idx_sig_enrich_treatment <-
        intersect(which(final_data$p.mod < 0.05),
                  which(final_data$logFC > fc_threshold))
      idx_sig_enrich_control <-
        intersect(which(final_data$p.mod < 0.05),
                  which(final_data$logFC < -fc_threshold))
      final_data_treatment <-
        final_data[idx_sig_enrich_treatment, ]
      writexl::write_xlsx(
        final_data_treatment,
        paste(
          plot_dir,
          '/',
          'enriched_treatment_statistically_significant',
          '.xlsx',
          sep = ''
        )
      )

      final_data_control <- final_data[idx_sig_enrich_control, ]
      writexl::write_xlsx(
        final_data_control,
        paste(
          plot_dir,
          '/',
          'enriched_control_statistically_significant',
          '.xlsx',
          sep = ''
        )
      )

      ## Extract all peptdes with logFC > fc_threshold,  don't care Pvalue ##
      idx_sig_enrich_treatment <-
        which(final_data$logFC > fc_threshold)
      final_data_treatment_Pval_DC <-
        final_data[idx_sig_enrich_treatment, ]
      writexl::write_xlsx(
        final_data_treatment_Pval_DC,
        paste(
          plot_dir,
          '/',
          'enriched_treatment_FC_grt_fc_cutoff_Pval_DC',
          '.xlsx',
          sep = ''
        )
      )

      ## Extract all peptdes with logFC < -fc_threshold,  don't care Pvalue ##
      idx_sig_enrich_control <-
        which(final_data$logFC < -fc_threshold)
      final_data_control_Pval_DC <-
        final_data[idx_sig_enrich_control, ]
      writexl::write_xlsx(
        final_data_control_Pval_DC,
        paste(
          plot_dir,
          '/',
          'enriched_control_FC_less_-fc_cutoff_Pval_DC',
          '.xlsx',
          sep = ''
        )
      )

      ## Extract all peptdes with logFC > 0,  don't care Pvalue ##
      idx_sig_enrich_treatment <- which(final_data$logFC > 0)
      final_data_treatment_FC_grt_0_Pval_DC <-
        final_data[idx_sig_enrich_treatment, ]
      writexl::write_xlsx(
        final_data_treatment_FC_grt_0_Pval_DC,
        paste(
          plot_dir,
          '/',
          'enriched_treatment_FC_grt_0_Pval_DC',
          '.xlsx',
          sep = ''
        )
      )

      ####### Extract all peptdes with logFC < 0,  don't care Pvalue ########
      idx_sig_enrich_control <- which(final_data$logFC < 0)
      final_data_control_FC_less_0_Pval_DC <-
        final_data[idx_sig_enrich_control, ]
      writexl::write_xlsx(
        final_data_control_FC_less_0_Pval_DC,
        paste(
          plot_dir,
          '/',
          'enriched_control_FC_less_0_Pval_DC',
          '.xlsx',
          sep = ''
        )
      )
    }
  }
hist_png <-
  function(data,
           nan_remove,
           filename,
           xlabel,
           ylabel,
           title) {
    png(paste0(filename, ".png"))
    if (nan_remove == 1) {
      hist(
        data,
        na.rm = TRUE,
        xlab = xlabel,
        ylab = ylabel,
        main =  title
      )
    } else{
      hist(data,
           xlab = xlabel,
           ylab = ylabel,
           main =  title)
    }
    dev.off()
  }

boxplot_png <- function(data, filename, title) {
  png(paste0(filename, ".png"))
  boxplot(data, main = title)
  dev.off()
}
