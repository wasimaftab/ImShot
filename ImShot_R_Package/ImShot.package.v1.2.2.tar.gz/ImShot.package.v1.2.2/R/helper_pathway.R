#' @title  plot the pathway enrichment result into the cytoscape window directly
#' using RCy3 package Note: cytoscape window must be already open
#'
#' @param data this is the result returned by ReactomePA::enrichPathway(...)
#' @param cyto_title title of the netwok in cytoscape
#' @param max_path_show maximum number of pathways to be displayed

plot_pathway_cytoscape <- function(data,
                                 cyto_title,
                                 max_path_show)
{
  if (nrow(data) > max_path_show) {
    data <- data[1:max_path_show,]
  }

  links <- c()

  ## connect two pathway terms by an edge if there exist common genes between them
  for (i in 1:(nrow(data) - 1)) {
    # browser()
    temp <- unlist(strsplit(as.character(data$geneID[i]), "/"))
    for (j in (i + 1):nrow(data)) {
      temp2 <- unlist(strsplit(as.character(data$geneID[j]), "/"))
      gene_intersect <- intersect(temp, temp2)
      if (length(gene_intersect) != 0) {
        # browser()
        links <-
          rbind(links, cbind(
            as.data.frame(data$Description[i]),
            as.data.frame(data$Description[j]),
            length(gene_intersect)
          ))
      }
    }
  }
  ## Give proper names to the header
  colnames(links) <- c("from", "to", "thickness")

  ## node table
  nodes <- data.frame(id = data$Description,
                      stringsAsFactors = FALSE)

  ## Adjust node sizes to fit to an interval
  desire_lower_bound <- 10
  desire_upper_bound <- 16

  ## node attr. table
  node_attr <- data.frame(
    id = data$Description,
    node_size = MapNodeSize(data$Count, desire_lower_bound, desire_upper_bound),
    node_col = data$p.adjust,
    node_font_size = rep(12, nrow(data)),
    node_font_face = rep("Bitstream Vera Sans", nrow(data)),
    stringsAsFactors = FALSE
  )

  ## edge table
  edges <- data.frame(
    source = links$from,
    target = links$to,
    interaction = rep(c("interacts"), nrow(links)),
    # optional
    # weight = 10 * (links$thickness / sum(links$thickness)),
    weight = MapEdgeThickNess(links$thickness, 1, 3),
    # numeric
    stringsAsFactors = FALSE
  )

  RCy3::createNetworkFromDataFrames(nodes, edges, title = cyto_title, collection =
                                      "Pathway Network from DataFrame")

  RCy3::loadTableData (data = node_attr,
                       data.key.column = 'id')

  ####### Create Visual Styles ###########
  style.name = "myStyle"
  defaults <- list(NODE_SHAPE = "ellipse",
                   NODE_LABEL_POSITION = "W,E,c,0.00,0.00")
  nodeLabels <- RCy3::mapVisualProperty('node label', 'id', 'p')

  edgeWidth <- RCy3::mapVisualProperty('edge width', 'weight', 'p')

  RCy3::createVisualStyle(style.name,
                          defaults,
                          list(nodeLabels, edgeWidth))

  RCy3::setVisualStyle(style.name)

  RCy3::setNodeColorMapping(
    table.column = 'node_col',
    table.column.values =  c(min(node_attr$node_col), max(node_attr$node_col)),
    colors = c("#dd1c77", "#e7e1ef"),
    mapping.type = 'c',
    style.name = style.name
  )

  RCy3::setNodeSizeBypass(node.names = node_attr$id,
                          new.sizes = as.double(node_attr$node_size))

  RCy3::setNodeFontFaceBypass(node.names = node_attr$id,
                              new.fonts = node_attr$node_font_face)

  RCy3::setNodeFontSizeBypass(node.names = node_attr$id,
                              new.sizes = node_attr$node_font_size)

  RCy3::setNodeBorderWidthDefault(new.width = 1.5,
                                  style.name = style.name)

  RCy3::setEdgeColorDefault(new.color = '#666666',
                            style.name = style.name)
  ## Add node sizes as legends
  legend_df <- create_legend_df(data$Count, node_attr$node_size)
  legend_names <- rownames(legend_df)
  RCy3::addCyNodes(legend_names)
  RCy3::loadTableData(legend_df)
  # Color legend nodes in black
  RCy3::setNodeColorBypass(legend_names, "#000000")

  if (nrow(legend_df) >= 3) {
    # position
      RCy3::setNodePropertyBypass(legend_names,
                          c("E,W,l,5,0", "E,W,l,5,0", "E,W,l,5,0"),
                          "NODE_LABEL_POSITION")
      # node_anchor, label_anchor, justification, x-offset, y-offset
      RCy3::setNodePropertyBypass(legend_names,
                          c("-500", "-500", "-500"),
                          "NODE_X_LOCATION")

      RCy3::setNodePropertyBypass(legend_names,
                          c("300", "320", "340"),
                          "NODE_Y_LOCATION")
  } else if (nrow(legend_df) == 2){
    # position
      RCy3::setNodePropertyBypass(legend_names,
                          c("E,W,l,5,0", "E,W,l,5,0"),
                          "NODE_LABEL_POSITION")

      RCy3::setNodePropertyBypass(legend_names,
                          c("-500", "-500"),
                          "NODE_X_LOCATION")

      RCy3::setNodePropertyBypass(legend_names,
                          c("300", "320"),
                          "NODE_Y_LOCATION")

  }else{
    # position
      RCy3::setNodePropertyBypass(legend_names,
                          c("E,W,l,5,0"),
                          "NODE_LABEL_POSITION")

      RCy3::setNodePropertyBypass(legend_names,
                          c("-500"),
                          "NODE_X_LOCATION")

      RCy3::setNodePropertyBypass(legend_names,
                          c("300"),
                          "NODE_Y_LOCATION")
  }

  RCy3::setNodeLabelBypass(legend_names, legend_df$legend.label)
  RCy3::setNodeSizeBypass(node.names = legend_names,
                    new.sizes = legend_df$size)

}
################################################################################
#' Helper function to compute pathway enrichment
#' @param uniprot_list list for which enrich is computed
#' @param bg_uniprot background used in hypergeometric test
#' @param db Genome wide annotation database name, e.g. "org.Mm.eg.db"
#' @return ePath an S4 object containing results
#'
get_pathways <- function(uniprot_list, bg_uniprot, db) {
  eg <-
    clusterProfiler::bitr(
      uniprot_list,
      fromType = "UNIPROT",
      toType = "ENTREZID",
      OrgDb = db
    )

  ## Convert background Uniprots to ENTREZ IDs
  eg_bg <-
    clusterProfiler::bitr(
      bg_uniprot$uniprot ,
      fromType = "UNIPROT",
      toType = "ENTREZID",
      OrgDb = db
    )
  ePath <-
    ReactomePA::enrichPathway(
      gene = eg$ENTREZID,
      organism = "mouse",
      pvalueCutoff = 0.05,
      pAdjustMethod = "BH",
      universe = eg_bg$ENTREZID,
      readable = TRUE,
      minGSSize = 1,
      maxGSSize = 500
    )
  return(ePath)
}
################################################################################
