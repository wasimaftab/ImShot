#' Pathway enrichment analysis of the protein list(s)
#'
#' @description Performs over-representation test (as implemented in ReactomePA)
#' to discover whether biological pathways annotates the list of proteins at a
#' frequency greater than that would be expected by chance. This substantiates
#' the location of protein in situ by correlating cellular pathways to tissue morphology/cell types.
#'
#' @param enrichment_path Path to the folder containing gene/protein list(s)
#' @param species_background Path to the text file containing uniprot ids (which we
#' want to use as background for hypergeometric test). This file must be present inside
#' a subfolder (Background) inside enrichment_path folder. If this parameter is missing,
#' then all genes listed in the database (e.g., TERM2GENE table) will be used as background.
#' @param annot_db Genome wide annotation database for species, e.g. "org.Mm.eg.db" for mouse
#' @param pathway_db Pathway database. Either KEGG or Reactome
#' @param kegg_code Kegg codes for organisms (see http://www.genome.jp/kegg/catalog/org_list.html)
#' e.g., kegg code for mouse is mmu
#' @param min_gs_size Minimal number of genes annotated by Ontology term for testing
#' @param max_gs_size Maximal number of genes annotated for testing
#' @param pvalue_cutoff Adjusted pvalue cutoff on enrichment tests to report
#' @param padjust_method One of "holm", "hochberg", "hommel", "bonferroni", "BH", "BY", "fdr", "none"
#' @param max_path_show Maximum number of pathways to be displayed
#' @param output_folder_path (optional parameter) Path to write the results. By
#' default it a timestamped folder inside a subfolder in the user config directory
#' which is for,
#'
#' Windows = "C:/Users/<User>/AppData/Roaming/ImShot_Electron_App/Results_GO"
#'
#' Linux = "/home/<User>/.config/ImShot_Electron_App/Results_GO"
#'
#' Mac = "/Users/<User>/Library/Application Support/ImShot_Electron_App/Results_GO"
#'@export

pathway_enrichment_analysis <- function(enrichment_path,
                                        species_background = 'Default',
                                        annot_db,
                                        pathway_db,
                                        kegg_code,
                                        min_gs_size,
                                        max_gs_size,
                                        pvalue_cutoff,
                                        padjust_method,
                                        max_path_show,
                                        output_folder_path) {
  ## Fix the path
  enrichment_path <-
    normalizePath(enrichment_path, winslash = '/')

  ## Set output folder path if missing
  results_folder_name <- 'ImShot_Electron_App'
  if (missing(output_folder_path)) {
    dir.create(file.path(
      normalizePath(rappdirs::user_config_dir(), winslash = '/'),
      results_folder_name
    ),
    showWarnings = FALSE)
    output_folder_path <-
      normalizePath(file.path(
        normalizePath(rappdirs::user_config_dir(), winslash = '/'),
        results_folder_name
      ),
      winslash = '/')
  } else {
    output_folder_path <-
      normalizePath(output_folder_path, winslash = '/')
  }

  filtered_list <-
    list.files(normalizePath(enrichment_path), '*.xlsx')
  if (length(filtered_list) == 0) {
    stop(paste(
      'There are no filtered masslist in the folder:',
      normalizePath(enrichment_path)
    ))
  }

  for (i in 1:length(filtered_list)) {
    file_name <- filtered_list[i]
    full_file_name <-
      paste0(normalizePath(enrichment_path),
             "/",
             file_name)
    T <- as.data.frame(readxl::read_xlsx(full_file_name, 1))
    T <-
      dplyr::select(T, dplyr::matches("uniprot", ignore.case = TRUE))
    colnames(T) <- "uniprot"

    organism = switch(kegg_code,
                      "mmu" = 'mouse',
                      "dme" = 'fly',
                      "hsa" = 'human')

    ## convert uniprot to entrez
    eg <-
      clusterProfiler::bitr(T$uniprot,
                            fromType = "UNIPROT",
                            toType = "ENTREZID",
                            OrgDb = annot_db)
    if (pathway_db == 'Reactome') {
      if (species_background == 'Default') {
        ePath <-
          ReactomePA::enrichPathway(
            gene = eg$ENTREZID,
            organism = organism,
            pvalueCutoff = pvalue_cutoff,
            pAdjustMethod = padjust_method,
            readable = TRUE,
            minGSSize = min_gs_size,
            maxGSSize = max_gs_size
          )
      } else {
        ## construct full path from relative path to read data file for Pathway analysis
        species_background <-
          normalizePath(species_background, winslash = '/')

        ## read background set
        bg_uniprot <-
          as.data.frame(read.table(species_background, header = TRUE))
        bg_uniprot <-
          dplyr::select(bg_uniprot,
                        dplyr::matches("uniprot", ignore.case = TRUE))
        colnames(bg_uniprot) <- "uniprot"

        ## Convert background Uniprots to ENTREZ IDs
        eg_bg <-
          clusterProfiler::bitr(
            bg_uniprot$uniprot,
            fromType = "UNIPROT",
            toType = "ENTREZID",
            OrgDb = annot_db
          )
        # min_gs_size is the minimal number of genes which at least one term in the (custom)
        # ontology needs to have, which are also in the list of genes-of-interest. I.e.
        # there must be at least min_gs_size genes which are in the list of genes tested
        # (genes of interest), and these same genes must also be in at least one term in
        # the ontology used for testing (a term which might contain many more other genes as well).
        ePath <-
          ReactomePA::enrichPathway(
            gene = eg$ENTREZID,
            organism = organism,
            pvalueCutoff = pvalue_cutoff,
            pAdjustMethod = padjust_method,
            universe = eg_bg$ENTREZID,
            readable = TRUE,
            minGSSize = min_gs_size,
            maxGSSize = max_gs_size
          )
        print(paste(filtered_list[i], "processed successfully!"))
      }
    } else if (pathway_db == 'KEGG') {
      ####  KEGG over-representation test  ####
      if (species_background == 'Default') {
        ePath <- clusterProfiler::enrichKEGG(
          gene = eg$ENTREZID,
          organism = organism,
          keyType = 'kegg',
          pvalueCutoff = pvalue_cutoff,
          pAdjustMethod = padjust_method,
          minGSSize = min_gs_size,
          maxGSSize = max_gs_size,
          use_internal_data = FALSE
        )
      } else{
        ## construct full path from relative path to read data file for Pathway analysis
        species_background <-
          normalizePath(species_background, winslash = '/')


        ## read background set
        bg_uniprot <-
          as.data.frame(read.table(species_background, header = TRUE))
        bg_uniprot <-
          dplyr::select(bg_uniprot, dplyr::matches("uniprot"))
        colnames(bg_uniprot) <- "uniprot"

        ## Convert background Uniprots to ENTREZ IDs
        eg_bg <-
          clusterProfiler::bitr(
            bg_uniprot$uniprot,
            fromType = "UNIPROT",
            toType = "ENTREZID",
            OrgDb = annot_db
          )

        ePath <- clusterProfiler::enrichKEGG(
          gene = eg$ENTREZID,
          organism = organism,
          keyType = 'kegg',
          pvalueCutoff = pvalue_cutoff,
          pAdjustMethod = padjust_method,
          universe = eg_bg$ENTREZID,
          minGSSize = min_gs_size,
          maxGSSize = max_gs_size,
          use_internal_data = FALSE
        )
      }
      print(paste(filtered_list[i], "processed successfully!"))
    }

    ## Check if pathway df is not empty
    if (nrow(ePath@result) != 0) {
      ## Check if pathway df contains statistically significant entries
      idx <- which(ePath@result$p.adjust < 0.05)
      if (length(idx) != 0) {
        Pathway_data <- ePath@result[idx, ]

        ## Plot the pathway network in Cytoscape
        plot_pathway_cytoscape(Pathway_data,
                               paste0(gsub('\\.xlsx', "_", file_name), kegg_code, '_', pathway_db),
                               max_path_show)


        ## Write Pathway_data dataframe to a file
        dir.create(file.path(output_folder_path, 'Results_Pathway'),
                   showWarnings = FALSE)
        sub_dir <-
          paste0("Results_Pathway/",
                 format(Sys.time(), "%Y%m%d_%H%M%S"))
        dir.create(file.path(output_folder_path,
                             sub_dir),
                   showWarnings = FALSE)

        filename_Pathway_data <-
          paste0(file.path(output_folder_path, sub_dir, fsep = '/'),
                 '/ORT_',
                 file_name)
        writexl::write_xlsx(Pathway_data, filename_Pathway_data, col_names = TRUE)
      } else {
        print('No significant Pathways found after p-value adjustment')
      }
    } else {
      print('EITHER No gene set have size > min_gs_size OR No gene set have size < max_gs_size')
    }

  }
}
