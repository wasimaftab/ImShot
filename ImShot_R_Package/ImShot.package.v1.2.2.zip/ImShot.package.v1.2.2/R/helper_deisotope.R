#' Sanity check: stop if mq_file_path variable is missing
#' @param mq_file_path path to a maxquant output file (proteingroups/peptides)
missing_mq_file_path <- function(mq_file_path) {
    if (missing(mq_file_path)) {
        stop('mq_file_path variable is missing')
    }
}


#' Create folder for output
#' @param full_path to the IMS cluster masslist (Imaging mass spec output)
#' @param output_dir Path to write the output files
create_output_folder <- function(full_path, output_dir) {
  if (missing(full_path) || missing(output_dir)) {
    stop("MISSING argument: Please provide required arguments to create output folder")
  }
  dir.create(file.path(full_path, output_dir), showWarnings = FALSE)
}


#' read binary bit 1 or 0
#' @param str instructions for input
#' @return n returns user input 1/0
read_integer_binary <- function(str)
{
  n <- readline(prompt = str)
  n <- as.integer(n)
  if (is.na(n) || (n < 0) || (n > 1)) {
    print("Enter positive integer only")
    n <- readinteger_binary(str)
  }
  return(n)
}


#' Desiotpe IMS mass list
#' @param ims_mass double datatype, mass list from IMS experiment
#' @param tol tolerance for deisotoping
#' @return returns ims mass list after deisotoping
#' @author Wasim Aftab and Shibojyoti Lahiri
deisotoping <- function(ims_mass, tol) {
  idx_remove_IMS_mass = c()
  lb <- 1 - tol
  ub <- 1 + tol
  for (i in 1:length(ims_mass)) {
    m <- ims_mass[i]
    idx_remove_IMS_mass <-
      c(idx_remove_IMS_mass, which((ims_mass >= (m + lb)) &
                                     (ims_mass <= (m + ub))))
  }

  ims_mass_deisotoped <- ims_mass[-idx_remove_IMS_mass]

  return(ims_mass_deisotoped)
}

#' Find consecutive masses
#' @param ims_mass_round double datatype, fraction part truncated ims mass list after 1st round of deisotoping
#' @return Returns consecutive masses in the list
find_consecutive_masses <- function(ims_mass_round) {
  l <- c()
  for (i in 1:(length(ims_mass_round) - 1)) {
    if (abs(ims_mass_round[i] - ims_mass_round[i + 1]) == 1) {
      l <- c(l, ims_mass_round[i:(i + 1)])
    }
  }
  l <- unique(l)
  return(l)
}


#' This function returns the mass associated with the actual peak
#' @param consecutive_masses consecutive masses in the list
#' @param ims_spectrum entire spectrum of imaging mass spec experiment
#' @return Returns IMS masses after peak correction
correct_masses <- function(consecutive_masses, ims_spectrum) {
  # browser()
  if (missing(consecutive_masses)) {
    stop("MISSING argument(s): Please provide consecutive masses")
  } else if (missing(ims_spectrum)) {
    stop("MISSING argument(s): Please provide IMS spectrum")
  }
  mass_corrected <- consecutive_masses
  for (i in 1:length(consecutive_masses)) {
    idx <- which((ims_spectrum$mass >= consecutive_masses[i]) &
                   (ims_spectrum$mass <= (consecutive_masses[i] + 1)))
    idx2 <-
      which(ims_spectrum$Int[idx] == max(ims_spectrum$Int[idx]))
    mass_corrected[i] <- ims_spectrum$mass[idx[idx2]]
  }
  return(mass_corrected)
}

#################################################################################
#' Search within tolerance in LIMMA peptide results
#' @param tol double scalar implies accuracy of IMS measurements
#' @param ims_mass_deisotoped double list containing ims masses after two rounds of deisotoping
#' @param limma_pep_df data frame containing limma results for either LogFC < 0 AND Pvalue DON'T CARE | LogFC > 0 AND Pvalue DON'T CARE |  LogFC < 0 AND Pvalue DON'T CARE | LogFC > 1.5 AND Pvalue < 0.05
#' @return Returns a dataframe of LC-MS peptde masses that fall within the IMS tolerance
search_within_tolerance <-
  function(tol,
           ims_mass_deisotoped,
           limma_pep_df) {
    idx_mass_col <-
      grep('^mass$', colnames(limma_pep_df), ignore.case = TRUE)
    limma_pep_df_mass <- limma_pep_df[, idx_mass_col] + 1.008
    limma_pep_df_filtered <- c()
    idx_mean_inten_col <-
      which(grepl(
        pattern = "mean",
        colnames(limma_pep_df),
        ignore.case = TRUE
      ))
    for (i in 1:length(ims_mass_deisotoped)) {
      idx_match <-
        which((limma_pep_df_mass >= (ims_mass_deisotoped[i] - tol)) &
                (limma_pep_df_mass <= (ims_mass_deisotoped[i] + tol)))
      if (length(idx_match) != 0) {
        temp <- limma_pep_df[idx_match, ]
        sort_obj <-
          sort(temp[, idx_mean_inten_col], index.return = TRUE)
        limma_pep_df_filtered <-
          rbind(limma_pep_df_filtered, temp[sort_obj$ix, ])
      }
    }
    return(limma_pep_df_filtered)
  }
################################################################################
#' Ranking LCMS peptides that fall within the accuracy of IMS measurement of an IMS peptide
#' @param limma_pep_df_filtered data frame containing filtered limma results for either LogFC < 0 | LogFC > 0 |  LogFC < -cut_off AND Pvalue < 0.05 | LogFC > cut_off AND Pvalue < 0.05.
#' only those Lcms peptide masses that fall within the accuracy of IMS  measurements
#' @param tol double scalar implies accuracy of IMS measurements. In this function using lsightly increased tolerance to make sure boundary is achieved
#' @return Returns a list containing two data frames corresponding to best and second best mlp ranked Lcms peptides and associated informations that fall within the accuracy of IMS  measurements
mlp_filtering <- function(limma_pep_df_filtered, tol) {
  top_uniq_hits <- c()
  second_uniq_hits <- c()
  third_uniq_hits <- c()
  idx_mass_col <-
    grep('^mass$', colnames(limma_pep_df_filtered), ignore.case = TRUE)
  masses <- limma_pep_df_filtered[, idx_mass_col]
  num_cols <- ncol(limma_pep_df_filtered)
  df_for_mlp <-
    dplyr::select(limma_pep_df_filtered, matches("^mean_|^logFC$|^Pvalue_limma$", ignore.case = TRUE))
  if (ncol(df_for_mlp) != 3){
    stop('Columns(s) missing in the mlp dataframe')
  }
  colnames(df_for_mlp)[3] <- c('p_mod')
  i <- 1
  while (i <= length(masses)) {
    m <- masses[i]
    idx <- which((masses >= (m - tol)) & (masses <= (m + tol)))
    idx_mean <- grep("^mean_", colnames(df_for_mlp), ignore.case = TRUE)
    grouped_data <- limma_pep_df_filtered[idx, ]
    # mlp <-
    #   (df_for_mlp[idx, 1] * abs(df_for_mlp[idx, 2])) / df_for_mlp[idx, 3]
    # browser()
    mlp <-
      (df_for_mlp[idx, idx_mean] * abs(df_for_mlp$logFC[idx])) / df_for_mlp$p_mod[idx]
    max_mlp <- max(mlp)
    mlp <- mlp / max_mlp[1]
    i <- i + length(idx)
    sort_obj <-
      sort(mlp, index.return = TRUE, decreasing = TRUE)
    grouped_data <-
      cbind(grouped_data[sort_obj$ix, ], mlp[sort_obj$ix])
    if (nrow(grouped_data) == 1) {
      top_uniq_hits <- rbind(top_uniq_hits, grouped_data)
    }
    # else if (nrow(grouped_data) >= 2) {
    #   top_uniq_hits <- rbind(top_uniq_hits, grouped_data[1, ])
    #   second_uniq_hits <-
    #     rbind(second_uniq_hits, grouped_data[2, ])
    # }
    else if (nrow(grouped_data) > 2) {
      top_uniq_hits <- rbind(top_uniq_hits, grouped_data[1, ])
      second_uniq_hits <-
        rbind(second_uniq_hits, grouped_data[2, ])
      third_uniq_hits <-
        rbind(third_uniq_hits, grouped_data[3, ])
    } else if (nrow(grouped_data) == 2) {
      top_uniq_hits <- rbind(top_uniq_hits, grouped_data[1, ])
      second_uniq_hits <-
        rbind(second_uniq_hits, grouped_data[2, ])
    }
  }

  final_list <-
    setNames(vector("list", 3), c('top', 'second', 'third'))
  if (exists('top_uniq_hits') && length(top_uniq_hits) != 0) {
    colnames(top_uniq_hits)[ncol(top_uniq_hits)] <- c("mlp_score")
    final_list$top <- top_uniq_hits
  }

  if (exists('second_uniq_hits') && length(second_uniq_hits) != 0) {
    colnames(second_uniq_hits)[ncol(second_uniq_hits)] <- c("mlp_score")
    final_list$second <- second_uniq_hits
  }

  if (exists('third_uniq_hits') && length(third_uniq_hits) != 0) {
    colnames(third_uniq_hits)[ncol(third_uniq_hits)] <- c("mlp_score")
    final_list$third <- third_uniq_hits
  }
  return(final_list)
}

################################################################################
#' @title  write results after tolerance search in LIMMA results
#' @param limma_pep_df_filtered tolerance search results
#' @param ims_raw_files_dir path of the IMS raw files
#' @param ims_raw_file_name file name containing raw IMS masss list
#' @param log_file log file
#' @param log_file_tag tag in log file
write_ims_lcms_limma_Search <-
  function(limma_pep_df_filtered,
           ims_raw_files_dir,
           ims_raw_file_name,
           log_file_tag,
           log_file) {
    file_tag <- gsub(":", "", log_file_tag)
    if (length(limma_pep_df_filtered) != 0) {
      ## write output to excel
      filename_lcms_ims <-
        file.path(
          normalizePath(ims_raw_files_dir),
          "Output",
          gsub(".xlsx", paste0("_", file_tag, ".xlsx"), ims_raw_file_name)
        )
      writexl::write_xlsx(limma_pep_df_filtered, filename_lcms_ims, col_names = TRUE)
    } else{
      ## Write to the log file
      log <-
        paste0(log_file_tag,
               " No matching IMS mass was found for ",
               ims_raw_file_name,
               " on ",
               date())
      write(log, file = log_file, append = TRUE)
    }
  }
################################################################################

#' Write to the log file
#' @param ims_raw_file_name file name containing raw IMS masss list
#' @param log_file log file
#' @param log_file_tag tag in log file
write_log <- function(ims_raw_file_name,
                      log_file_tag,
                      log_file)  {
    log <-
        paste0(log_file_tag,
               " No matching IMS mass was found for ",
               ims_raw_file_name,
               " on ",
               date())
    write(log, file = log_file, append = TRUE)
}


################################################################################
#' write results after mlp filtering
#' @param mlp_filtered_pep_df list containing two data frames corresponding to
#' best and second best mlp ranked Lcms peptides and associated informations
#' that fall within the accuracy of IMS  measurements
#' @param mlp_filtered_dir folder to write mlp filtered mass lists
#' @param ims_raw_file_name file name of raw IMS masss list
#' @param log_file_tag tag in log file
write_mlp_filtering <- function(mlp_filtered_pep_df,
                                mlp_filtered_dir,
                                ims_raw_file_name,
                                log_file_tag) {
  file_tag <- gsub("mlp_", "", gsub(":", "", log_file_tag))

  ## write top mlp results to excel
  if (!is.null(mlp_filtered_pep_df$top)) {
    filename_mlp_top <-
      paste0(mlp_filtered_dir, '/', paste0("Top_MLP_",
                                           gsub(
                                             ".xlsx", paste0("_", file_tag, ".xlsx"), ims_raw_file_name
                                           )))
    writexl::write_xlsx(mlp_filtered_pep_df$top,
                        filename_mlp_top,
                        col_names = TRUE)
  }

  ## write second best mlp results to excel
  if (!is.null(mlp_filtered_pep_df$second)) {
    filename_mlp_sec <-
      paste0(mlp_filtered_dir, '/', paste0("Second_MLP_",
                                           gsub(
                                             ".xlsx", paste0("_", file_tag, ".xlsx"), ims_raw_file_name
                                           )))
    writexl::write_xlsx(mlp_filtered_pep_df$second,
                        filename_mlp_sec,
                        col_names = TRUE)
  }

  ## write third best mlp results to excel
  if (!is.null(mlp_filtered_pep_df$third)) {
    filename_mlp_third <-
      paste0(mlp_filtered_dir, '/', paste0("Third_MLP_",
                                           gsub(
                                             ".xlsx", paste0("_", file_tag, ".xlsx"), ims_raw_file_name
                                           )))
    writexl::write_xlsx(mlp_filtered_pep_df$third,
                        filename_mlp_third,
                        col_names = TRUE)
  }
}
